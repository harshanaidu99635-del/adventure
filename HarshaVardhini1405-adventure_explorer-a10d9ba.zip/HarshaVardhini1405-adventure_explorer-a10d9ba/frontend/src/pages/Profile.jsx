import { useState, useContext } from 'react'
import { useParams } from 'react-router-dom'
import { useQuery } from '@tanstack/react-query'
import { FaMapMarkerAlt, FaGlobe, FaCalendar, FaThList, FaHeart, FaStar, FaEdit } from 'react-icons/fa'
import { getUserProfile, getPosts, getSavedDestinations, getReviews } from '../services/destinations'
import PostCard from '../components/PostCard'
import DestinationCard from '../components/DestinationCard'
import ReviewCard from '../components/ReviewCard'
import EditProfileModal from '../components/EditProfileModal'
import { useAuth } from '../context/AuthContext'
import { format } from 'date-fns'

const Profile = () => {
  const { username } = useParams()
  const [activeTab, setActiveTab] = useState('posts')
  const [isEditModalOpen, setEditModalOpen] = useState(false)
  const { user: authUser } = useAuth()

  const { data: user, isLoading } = useQuery({
    queryKey: ['userProfile', username],
    queryFn: () => getUserProfile(username).then(res => res.data)
  })

  const { data: postsData } = useQuery({
    queryKey: ['userPosts', user?.id],
    queryFn: () => getPosts({ author: user.id }).then(res => res.data),
    enabled: !!user?.id && activeTab === 'posts'
  })

  const { data: savedDestinationsData } = useQuery({
    queryKey: ['userSavedDestinations', user?.id],
    queryFn: () => getSavedDestinations({ user_id: user.id }).then(res => res.data),
    enabled: !!user?.id && activeTab === 'saved'
  })

  const { data: reviewsData } = useQuery({
    queryKey: ['userReviews', user?.id],
    queryFn: () => getReviews({ user: user.id }).then(res => res.data),
    enabled: !!user?.id && activeTab === 'reviews'
  })

  const posts = postsData?.results || []
  const savedDestinations = savedDestinationsData?.results || []
  const reviews = reviewsData?.results || []

  if (isLoading) {
    return (
      <div className="flex justify-center items-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-600"></div>
      </div>
    )
  }

  return (
    <div className="container mx-auto px-4 py-8">
      {/* Profile Header */}
      <div className="card mb-8">
        <div className="flex items-start space-x-6">
          {/* Avatar */}
          <div className="w-24 h-24 rounded-full bg-primary-100 flex items-center justify-center text-primary-600 font-bold text-4xl overflow-hidden">
            {user?.profile?.profile_picture ? (
              <img src={user.profile.profile_picture} alt={user.username} className="w-full h-full object-cover" />
            ) : (
              <span>{user?.username?.[0]?.toUpperCase()}</span>
            )}
          </div>

          {/* Info */}
          <div className="flex-1">
            <div className="flex justify-between items-start">
              <div>
                <h1 className="text-3xl font-bold mb-2">{user?.username}</h1>
                {user?.first_name && (
                  <p className="text-gray-600 mb-3">
                    {user.first_name} {user.last_name}
                  </p>
                )}
              </div>
              {authUser?.username === username && (
                <button 
                  onClick={() => setEditModalOpen(true)}
                  className="btn btn-secondary btn-sm flex items-center"
                >
                  <FaEdit className="mr-2" /> Edit Profile
                </button>
              )}
            </div>
            
            {user?.profile?.bio && (
              <p className="text-gray-700 mb-4">{user.profile.bio}</p>
            )}

            <div className="flex flex-wrap gap-4 text-sm text-gray-600">
              {user?.profile?.location && (
                <div className="flex items-center space-x-1">
                  <FaMapMarkerAlt />
                  <span>{user.profile.location}</span>
                </div>
              )}
              {user?.profile?.website && (
                <div className="flex items-center space-x-1">
                  <FaGlobe />
                  <a
                    href={user.profile.website}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-primary-600 hover:underline"
                  >
                    Website
                  </a>
                </div>
              )}
              <div className="flex items-center space-x-1">
                <FaCalendar />
                <span>
                  Joined {format(new Date(user?.date_joined), 'MMMM yyyy')}
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-3 gap-4 mt-6 pt-6 border-t">
          <div className="text-center">
            <p className="text-2xl font-bold text-primary-600">{posts.length}</p>
            <p className="text-gray-600 text-sm">Posts</p>
          </div>
          <div className="text-center">
            <p className="text-2xl font-bold text-primary-600">
              {savedDestinations.length}
            </p>
            <p className="text-gray-600 text-sm">Saved</p>
          </div>
          <div className="text-center">
            <p className="text-2xl font-bold text-primary-600">
              {reviews.length}
            </p>
            <p className="text-gray-600 text-sm">Reviews</p>
          </div>
        </div>
      </div>

      {/* Tab Navigation */}
      <div className="mb-8 border-b">
        <nav className="-mb-px flex space-x-8" aria-label="Tabs">
          <button
            onClick={() => setActiveTab('posts')}
            className={`${
              activeTab === 'posts'
                ? 'border-primary-500 text-primary-600'
                : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
            } whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm flex items-center`}
          >
            <FaThList className="mr-2" /> Posts
          </button>
          <button
            onClick={() => setActiveTab('saved')}
            className={`${
              activeTab === 'saved'
                ? 'border-primary-500 text-primary-600'
                : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
            } whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm flex items-center`}
          >
            <FaHeart className="mr-2" /> Saved Destinations
          </button>
          <button
            onClick={() => setActiveTab('reviews')}
            className={`${
              activeTab === 'reviews'
                ? 'border-primary-500 text-primary-600'
                : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
            } whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm flex items-center`}
          >
            <FaStar className="mr-2" /> Reviews
          </button>
        </nav>
      </div>

      {/* Tab Content */}
      <div>
        {activeTab === 'posts' && (
          <div>
            <h2 className="text-2xl font-bold mb-6">Posts by {user?.username}</h2>
            {posts.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {posts.map((post) => (
                  <PostCard key={post.id} post={post} />
                ))}
              </div>
            ) : (
              <div className="text-center py-12 card">
                <p className="text-gray-500">No posts yet</p>
              </div>
            )}
          </div>
        )}

        {activeTab === 'saved' && (
          <div>
            <h2 className="text-2xl font-bold mb-6">Saved Destinations</h2>
            {savedDestinations.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {savedDestinations.map((saved) => (
                  <DestinationCard key={saved.id} destination={saved.destination} />
                ))}
              </div>
            ) : (
              <div className="text-center py-12 card">
                <p className="text-gray-500">No saved destinations yet</p>
              </div>
            )}
          </div>
        )}

        {activeTab === 'reviews' && (
          <div>
            <h2 className="text-2xl font-bold mb-6">Reviews by {user?.username}</h2>
            {reviews.length > 0 ? (
              <div className="space-y-6">
                {reviews.map((review) => (
                  <ReviewCard key={review.id} review={review} />
                ))}
              </div>
            ) : (
              <div className="text-center py-12 card">
                <p className="text-gray-500">No reviews yet</p>
              </div>
            )}
          </div>
        )}
      </div>

      {isEditModalOpen && (
        <EditProfileModal user={user} onClose={() => setEditModalOpen(false)} />
      )}
    </div>
  )
}

export default Profile
