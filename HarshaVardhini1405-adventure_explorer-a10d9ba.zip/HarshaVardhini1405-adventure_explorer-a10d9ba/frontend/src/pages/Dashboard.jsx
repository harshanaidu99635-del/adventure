import { useQuery } from '@tanstack/react-query'
import { FaMapMarkerAlt, FaPenFancy, FaStar } from 'react-icons/fa'
import { getMyPosts, getSavedDestinations, getMyReviews } from '../services/destinations'
import { useAuth } from '../context/AuthContext'
import PostCard from '../components/PostCard'
import DestinationCard from '../components/DestinationCard'
import ReviewCard from '../components/ReviewCard'
import { useState } from 'react'

const Dashboard = () => {
  const { user } = useAuth()
  const [activeTab, setActiveTab] = useState('posts')

  const { data: postsData, isLoading: loadingPosts } = useQuery({
    queryKey: ['myPosts'],
    queryFn: () => getMyPosts().then(res => res.data)
  })

  const { data: savedData, isLoading: loadingSaved } = useQuery({
    queryKey: ['savedDestinations'],
    queryFn: () => getSavedDestinations().then(res => res.data),
    enabled: activeTab === 'saved'
  })

  const { data: reviewsData, isLoading: loadingReviews } = useQuery({
    queryKey: ['myReviews'],
    queryFn: () => getMyReviews().then(res => res.data),
    enabled: activeTab === 'reviews'
  })

  const posts = postsData?.results || []
  const saved = savedData?.results || []
  const reviews = reviewsData?.results || []

  return (
    <div className="container mx-auto px-4 py-8">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-2">Dashboard</h1>
        <p className="text-gray-600">Welcome back, {user?.username}!</p>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <div className="card">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-gray-600 text-sm">My Posts</p>
              <p className="text-3xl font-bold">{posts.length}</p>
            </div>
            <div className="bg-primary-100 p-4 rounded-full">
              <FaPenFancy className="text-primary-600 text-2xl" />
            </div>
          </div>
        </div>
        
        <div className="card">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-gray-600 text-sm">Saved Places</p>
              <p className="text-3xl font-bold">{user?.profile?.countries_visited || 0}</p>
            </div>
            <div className="bg-primary-100 p-4 rounded-full">
              <FaMapMarkerAlt className="text-primary-600 text-2xl" />
            </div>
          </div>
        </div>
        
        <div className="card">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-gray-600 text-sm">Reviews</p>
              <p className="text-3xl font-bold">{reviews.length}</p>
            </div>
            <div className="bg-primary-100 p-4 rounded-full">
              <FaStar className="text-primary-600 text-2xl" />
            </div>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="card">
        <div className="flex border-b mb-6">
          <button
            onClick={() => setActiveTab('posts')}
            className={`px-6 py-3 font-medium ${
              activeTab === 'posts'
                ? 'border-b-2 border-primary-600 text-primary-600'
                : 'text-gray-500'
            }`}
          >
            My Posts
          </button>
          <button
            onClick={() => setActiveTab('saved')}
            className={`px-6 py-3 font-medium ${
              activeTab === 'saved'
                ? 'border-b-2 border-primary-600 text-primary-600'
                : 'text-gray-500'
            }`}
          >
            Saved Destinations
          </button>
          <button
            onClick={() => setActiveTab('reviews')}
            className={`px-6 py-3 font-medium ${
              activeTab === 'reviews'
                ? 'border-b-2 border-primary-600 text-primary-600'
                : 'text-gray-500'
            }`}
          >
            My Reviews
          </button>
        </div>

        {/* Tab Content */}
        <div>
          {activeTab === 'posts' && (
            <div>
              {loadingPosts ? (
                <div className="text-center py-8">Loading...</div>
              ) : posts.length > 0 ? (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {posts.map((post) => (
                    <PostCard key={post.id} post={post} />
                  ))}
                </div>
              ) : (
                <div className="text-center py-12">
                  <p className="text-gray-500 mb-4">You haven't created any posts yet</p>
                  <a href="/posts/create" className="btn btn-primary">
                    Create Your First Post
                  </a>
                </div>
              )}
            </div>
          )}

          {activeTab === 'saved' && (
            <div>
              {loadingSaved ? (
                <div className="text-center py-8">Loading...</div>
              ) : saved.length > 0 ? (
                <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-4 gap-6">
                  {saved.map((item) => (
                    <DestinationCard key={item.id} destination={item.destination} />
                  ))}
                </div>
              ) : (
                <div className="text-center py-12">
                  <p className="text-gray-500 mb-4">No saved destinations yet</p>
                  <a href="/explore" className="btn btn-primary">
                    Explore Destinations
                  </a>
                </div>
              )}
            </div>
          )}

          {activeTab === 'reviews' && (
            <div>
              {loadingReviews ? (
                <div className="text-center py-8">Loading...</div>
              ) : reviews.length > 0 ? (
                <div>
                  {reviews.map((review) => (
                    <ReviewCard key={review.id} review={review} />
                  ))}
                </div>
              ) : (
                <div className="text-center py-12">
                  <p className="text-gray-500">No reviews yet</p>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  )
}

export default Dashboard
