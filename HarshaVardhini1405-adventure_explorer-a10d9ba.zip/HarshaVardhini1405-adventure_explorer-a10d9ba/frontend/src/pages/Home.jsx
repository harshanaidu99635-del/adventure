import { Link } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { FaSearch, FaMapMarkedAlt, FaPenFancy, FaUsers } from 'react-icons/fa';
import { getPopularDestinations, getPopularPosts } from '../services/destinations';
import DestinationCard from '../components/DestinationCard';
import PostCard from '../components/PostCard';
import DestinationCardSkeleton from '../components/DestinationCardSkeleton';
import PostCardSkeleton from '../components/PostCardSkeleton';

const Home = () => {
  const { data: destinations, isLoading: loadingDestinations } = useQuery({
    queryKey: ['popularDestinations'],
    queryFn: () => getPopularDestinations().then(res => res.data),
    // Light realtime feel: refresh periodically and on focus
    refetchInterval: 30000,
    refetchOnWindowFocus: true,
    staleTime: 15000,
  });

  const { data: posts, isLoading: loadingPosts } = useQuery({
    queryKey: ['popularPosts'],
    queryFn: () => getPopularPosts().then(res => res.data),
    refetchInterval: 30000,
    refetchOnWindowFocus: true,
    staleTime: 15000,
  });

  return (
    <div className="bg-white">
      {/* Hero Section */}
      <section className="relative h-[600px] text-white">
        <div className="absolute inset-0">
          <img 
            src="https://images.unsplash.com/photo-1476514525535-07fb3b4ae5f1?auto=format&fit=crop&w=1920&q=80" 
            alt="Hero background" 
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-black opacity-50"></div>
        </div>
        <div className="relative z-10 flex flex-col items-center justify-center h-full text-center px-4">
          <h1 className="text-5xl md:text-7xl font-extrabold mb-4 leading-tight">
            Your Journey Begins Here
          </h1>
          <p className="text-lg md:text-xl mb-8 max-w-3xl">
            Uncover hidden gems, plan your next escape, and connect with a global community of explorers. Your adventure is just a click away.
          </p>
          <div className="flex flex-wrap justify-center gap-4">
            <Link to="/explore" className="btn btn-primary text-lg px-8 py-3">
              <FaSearch className="inline mr-2" />
              Explore Places
            </Link>
            <Link to="/register" className="btn btn-secondary text-lg px-8 py-3">
              Join The Community
            </Link>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold">Why Choose Traveller?</h2>
            <p className="text-gray-600 mt-2">Everything you need for your next adventure.</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-10">
            <div className="text-center p-6">
              <div className="bg-primary-100 text-primary-600 w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-5 shadow-lg">
                <FaMapMarkedAlt size={36} />
              </div>
              <h3 className="text-2xl font-bold mb-3">Vast Destinations</h3>
              <p className="text-gray-600">
                From bustling cities to serene landscapes, discover a world of destinations at your fingertips.
              </p>
            </div>
            <div className="text-center p-6">
              <div className="bg-green-100 text-green-600 w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-5 shadow-lg">
                <FaPenFancy size={36} />
              </div>
              <h3 className="text-2xl font-bold mb-3">Authentic Stories</h3>
              <p className="text-gray-600">
                Read real travel stories and reviews from our vibrant community to plan your perfect trip.
              </p>
            </div>
            <div className="text-center p-6">
              <div className="bg-blue-100 text-blue-600 w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-5 shadow-lg">
                <FaUsers size={36} />
              </div>
              <h3 className="text-2xl font-bold mb-3">Engaged Community</h3>
              <p className="text-gray-600">
                Share your own adventures, connect with fellow travelers, and get inspired for your next journey.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Popular Destinations (Trending) */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <div className="flex items-end justify-between mb-12">
            <div className="text-left">
              <h2 className="text-4xl font-bold flex items-center gap-3">
                Trending Destinations
                <span className="inline-block w-2 h-2 rounded-full bg-green-500 animate-pulse" title="Auto-updates"></span>
              </h2>
              <p className="text-gray-600 mt-2">Places that travelers are loving right now.</p>
            </div>
            <div className="hidden sm:block">
              <Link to="/explore" className="text-primary-600 hover:text-primary-700 font-semibold">View all</Link>
            </div>
          </div>
          
          {loadingDestinations ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
              {[...Array(4)].map((_, i) => (
                <DestinationCardSkeleton key={i} />
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
              {destinations?.slice(0, 4).map((destination) => (
                <DestinationCard key={destination.id} destination={destination} />
              ))}
            </div>
          )}
        </div>
      </section>

      {/* Recent Posts (Latest from the Community) */}
      <section className="py-20 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="flex items-end justify-between mb-12">
            <div className="text-left">
              <h2 className="text-4xl font-bold flex items-center gap-3">
                Latest from the Community
                <span className="inline-block w-2 h-2 rounded-full bg-green-500 animate-pulse" title="Auto-updates"></span>
              </h2>
              <p className="text-gray-600 mt-2">Fresh stories and tips from our travelers.</p>
            </div>
          </div>
          
          {loadingPosts ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {[...Array(3)].map((_, i) => (
                <PostCardSkeleton key={i} />
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {posts?.slice(0, 3).map((post) => (
                <PostCard key={post.id} post={post} />
              ))}
            </div>
          )}
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-cover bg-center text-white" style={{backgroundImage: "url('https://images.unsplash.com/photo-1501785888041-af3ef285b470?auto=format&fit=crop&w=1920&q=80')"}}>
        <div className="container mx-auto px-4 text-center bg-black bg-opacity-50 py-12 rounded-lg">
          <h2 className="text-4xl font-bold mb-4">Ready to Join?</h2>
          <p className="text-xl mb-8 max-w-2xl mx-auto">
            Create an account to save your favorite places, write reviews, and share your own travel stories with the world.
          </p>
          <Link to="/register" className="btn btn-primary text-lg px-10 py-4">
            Sign Up for Free
          </Link>
        </div>
      </section>
    </div>
  );
};

export default Home;
