import { useParams } from 'react-router-dom'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { useState } from 'react'
import { toast } from 'react-toastify'
import { format } from 'date-fns'
import { FaHeart, FaRegHeart, FaComment, FaEye, FaStar } from 'react-icons/fa'
import { getPost, likePost, unlikePost, addComment } from '../services/destinations'
import { useAuth } from '../context/AuthContext'

const PostDetail = () => {
  const { id } = useParams()
  const { user, isAuthenticated } = useAuth()
  const queryClient = useQueryClient()
  const [comment, setComment] = useState('')

  const { data: post, isLoading } = useQuery({
    queryKey: ['post', id],
    queryFn: () => getPost(id).then(res => res.data)
  })

  const likeMutation = useMutation({
    mutationFn: () => post?.is_liked ? unlikePost(id) : likePost(id),
    onSuccess: () => {
      queryClient.invalidateQueries(['post', id])
      toast.success(post?.is_liked ? 'Post unliked' : 'Post liked!')
    }
  })

  const commentMutation = useMutation({
    mutationFn: (content) => addComment(id, { content }),
    onSuccess: () => {
      setComment('')
      queryClient.invalidateQueries(['post', id])
      toast.success('Comment added!')
    }
  })

  const handleComment = (e) => {
    e.preventDefault()
    if (comment.trim()) {
      commentMutation.mutate(comment)
    }
  }

  if (isLoading) {
    return (
      <div className="flex justify-center items-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-600"></div>
      </div>
    )
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="mb-6">
          <div className="flex items-center justify-between mb-4">
            <a
              href={`/destinations/${post?.destination?.id}`}
              className="text-primary-600 hover:underline"
            >
              📍 {post?.destination?.name}
            </a>
            <div className="flex items-center space-x-1">
              {[...Array(5)].map((_, i) => (
                <FaStar
                  key={i}
                  className={i < post?.rating ? 'text-yellow-500' : 'text-gray-300'}
                />
              ))}
            </div>
          </div>
          <h1 className="text-4xl font-bold mb-4">{post?.title}</h1>
          
          {/* Author Info */}
          <div className="flex items-center space-x-3">
            <div className="w-12 h-12 rounded-full bg-primary-100 flex items-center justify-center text-primary-600 font-semibold text-lg">
              {post?.author_username?.[0]?.toUpperCase()}
            </div>
            <div>
              <a
                href={`/profile/${post?.author_username}`}
                className="font-medium hover:text-primary-600"
              >
                {post?.author_username}
              </a>
              <p className="text-sm text-gray-500">
                {post?.created_at && format(new Date(post.created_at), 'MMMM dd, yyyy')}
              </p>
            </div>
          </div>
        </div>

        {/* Featured Image */}
        {post?.featured_image && (
          <div className="mb-6 rounded-lg overflow-hidden">
            <img
              src={post.featured_image}
              alt={post.title}
              className="w-full h-96 object-cover"
            />
          </div>
        )}

        {/* Stats */}
        <div className="flex items-center space-x-6 mb-6 pb-6 border-b">
          <button
            onClick={() => likeMutation.mutate()}
            disabled={!isAuthenticated}
            className="flex items-center space-x-2 hover:text-red-500 transition"
          >
            {post?.is_liked ? (
              <FaHeart className="text-red-500" />
            ) : (
              <FaRegHeart />
            )}
            <span>{post?.likes_count}</span>
          </button>
          <div className="flex items-center space-x-2">
            <FaComment />
            <span>{post?.comments_count}</span>
          </div>
          <div className="flex items-center space-x-2">
            <FaEye />
            <span>{post?.views}</span>
          </div>
        </div>

        {/* Content */}
        <div className="prose max-w-none mb-8">
          <p className="text-gray-700 text-lg whitespace-pre-line">{post?.content}</p>
        </div>

        {/* Comments Section */}
        <div className="card">
          <h2 className="text-2xl font-bold mb-6">
            Comments ({post?.comments?.length || 0})
          </h2>

          {/* Add Comment */}
          {isAuthenticated ? (
            <form onSubmit={handleComment} className="mb-6">
              <textarea
                value={comment}
                onChange={(e) => setComment(e.target.value)}
                placeholder="Write a comment..."
                rows="3"
                className="input mb-2"
              />
              <button
                type="submit"
                disabled={!comment.trim() || commentMutation.isLoading}
                className="btn btn-primary"
              >
                {commentMutation.isLoading ? 'Posting...' : 'Post Comment'}
              </button>
            </form>
          ) : (
            <p className="text-gray-500 mb-6">
              Please <a href="/login" className="text-primary-600 hover:underline">login</a> to comment
            </p>
          )}

          {/* Comments List */}
          <div className="space-y-4">
            {post?.comments?.map((comment) => (
              <div key={comment.id} className="border-b pb-4 last:border-b-0">
                <div className="flex items-start space-x-3">
                  <div className="w-10 h-10 rounded-full bg-primary-100 flex items-center justify-center text-primary-600 font-semibold">
                    {comment.author_username?.[0]?.toUpperCase()}
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center space-x-2 mb-1">
                      <span className="font-medium">{comment.author_username}</span>
                      <span className="text-xs text-gray-500">
                        {format(new Date(comment.created_at), 'MMM dd, yyyy')}
                      </span>
                    </div>
                    <p className="text-gray-700">{comment.content}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}

export default PostDetail
