import { useParams } from 'react-router-dom'
import { useQuery, useMutation } from '@tanstack/react-query'
import { useState } from 'react'
import { toast } from 'react-toastify'
import { FaStar, FaMapMarkerAlt, FaBookmark, FaRegBookmark } from 'react-icons/fa'
import { getDestination, getPosts, getReviews, saveDestination, unsaveDestination } from '../services/destinations'
import { useAuth } from '../context/AuthContext'
import PostCard from '../components/PostCard'
import ReviewCard from '../components/ReviewCard'
import LocationMap from '../components/LocationMap'

const DestinationDetail = () => {
  const { id } = useParams()
  const { isAuthenticated } = useAuth()
  const [activeTab, setActiveTab] = useState('posts')

  const { data: destination, isLoading, refetch } = useQuery({
    queryKey: ['destination', id],
    queryFn: () => getDestination(id).then(res => res.data)
  })

  const { data: postsData } = useQuery({
    queryKey: ['posts', { destination: id }],
    queryFn: () => getPosts({ destination: id }).then(res => res.data),
    enabled: activeTab === 'posts'
  })

  const { data: reviewsData } = useQuery({
    queryKey: ['reviews', { destination: id }],
    queryFn: () => getReviews({ destination: id }).then(res => res.data),
    enabled: activeTab === 'reviews'
  })

  const saveMutation = useMutation({
    mutationFn: (isSaved) => isSaved ? unsaveDestination(id) : saveDestination(id),
    onSuccess: () => {
      toast.success(destination?.is_saved ? 'Removed from saved' : 'Added to saved!')
      refetch()
    }
  })

  if (isLoading) {
    return (
      <div className="flex justify-center items-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-600"></div>
      </div>
    )
  }

  const posts = postsData?.results || []
  const reviews = reviewsData?.results || []
  const heroImage = destination?.image_present || destination?.image_past

  return (
    <div>
      {/* Hero Image */}
      <div className="relative h-96 bg-gray-200">
        {heroImage && (
          <img
            src={heroImage}
            alt={destination.name}
            className="w-full h-full object-cover"
            loading="lazy"
          />
        )}
        <div className="absolute inset-0 bg-black bg-opacity-40 flex items-end">
          <div className="container mx-auto px-4 py-8 text-white">
            <span className="inline-block bg-primary-600 px-3 py-1 rounded-full text-sm mb-2">
              {destination?.category}
            </span>
            <h1 className="text-4xl font-bold mb-2">{destination?.name}</h1>
            <div className="flex items-center space-x-2 text-lg">
              <FaMapMarkerAlt />
              <span>{destination?.city}, {destination?.country}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2">
            {/* Description */}
            <div className="card mb-6">
              <h2 className="text-2xl font-bold mb-4">About This Place</h2>
              <p className="text-gray-700 whitespace-pre-line">{destination?.description}</p>
            </div>

            {(destination?.image_present || destination?.image_past) && (
              <div className="grid gap-4 md:grid-cols-2 mb-6">
                {destination?.image_present && (
                  <div className="card overflow-hidden p-0">
                    <div className="relative h-64">
                      <img
                        src={destination.image_present}
                        alt={`${destination?.name} present view`}
                        className="w-full h-full object-cover"
                        loading="lazy"
                      />
                      <span className="absolute top-3 left-3 bg-primary-600 text-white text-xs font-semibold px-3 py-1 rounded-full uppercase tracking-wide">Present</span>
                    </div>
                  </div>
                )}
                {destination?.image_past && (
                  <div className="card overflow-hidden p-0">
                    <div className="relative h-64">
                      <img
                        src={destination.image_past}
                        alt={`${destination?.name} historical view`}
                        className="w-full h-full object-cover"
                        loading="lazy"
                      />
                      <span className="absolute top-3 left-3 bg-gray-900 text-white text-xs font-semibold px-3 py-1 rounded-full uppercase tracking-wide">Past</span>
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* Location Map */}
            {destination && <LocationMap destination={destination} />}

            {/* Tabs */}
            <div className="card mt-6">
              <div className="flex border-b mb-4">
                <button
                  onClick={() => setActiveTab('posts')}
                  className={`px-6 py-3 font-medium ${
                    activeTab === 'posts'
                      ? 'border-b-2 border-primary-600 text-primary-600'
                      : 'text-gray-500'
                  }`}
                >
                  Posts ({postsData?.count || 0})
                </button>
                <button
                  onClick={() => setActiveTab('reviews')}
                  className={`px-6 py-3 font-medium ${
                    activeTab === 'reviews'
                      ? 'border-b-2 border-primary-600 text-primary-600'
                      : 'text-gray-500'
                  }`}
                >
                  Reviews ({reviewsData?.count || 0})
                </button>
              </div>

              {/* Tab Content */}
              <div>
                {activeTab === 'posts' && (
                  <div className="grid gap-6">
                    {posts.length > 0 ? (
                      posts.map(post => <PostCard key={post.id} post={post} />)
                    ) : (
                      <p className="text-center text-gray-500 py-8">No posts yet</p>
                    )}
                  </div>
                )}

                {activeTab === 'reviews' && (
                  <div>
                    {reviews.length > 0 ? (
                      reviews.map(review => <ReviewCard key={review.id} review={review} />)
                    ) : (
                      <p className="text-center text-gray-500 py-8">No reviews yet</p>
                    )}
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Sidebar */}
          <div className="lg:col-span-1">
            <div className="card sticky top-20">
              {/* Rating */}
              <div className="mb-6">
                <div className="flex items-center space-x-2 mb-2">
                  <div className="flex items-center">
                    {[...Array(5)].map((_, i) => (
                      <FaStar
                        key={i}
                        className={
                          i < Math.round(destination?.average_rating || 0)
                            ? 'text-yellow-500'
                            : 'text-gray-300'
                        }
                      />
                    ))}
                  </div>
                  <span className="text-2xl font-bold">
                    {destination?.average_rating || 0}
                  </span>
                </div>
                <p className="text-gray-600">{destination?.total_reviews} reviews</p>
              </div>

              {/* Stats */}
              <div className="space-y-3 mb-6 border-t pt-4">
                <div className="flex justify-between">
                  <span className="text-gray-600">Views</span>
                  <span className="font-semibold">{destination?.views}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Location</span>
                  <span className="font-semibold">{destination?.city}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Category</span>
                  <span className="font-semibold capitalize">{destination?.category}</span>
                </div>
              </div>

              {/* Actions */}
              {isAuthenticated && (
                <button
                  onClick={() => saveMutation.mutate(destination?.is_saved)}
                  className="w-full btn btn-outline flex items-center justify-center space-x-2"
                >
                  {destination?.is_saved ? <FaBookmark /> : <FaRegBookmark />}
                  <span>{destination?.is_saved ? 'Saved' : 'Save Destination'}</span>
                </button>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default DestinationDetail
