import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useQuery, useMutation } from '@tanstack/react-query'
import { useForm } from 'react-hook-form'
import { toast } from 'react-toastify'
import { FaStar } from 'react-icons/fa'
import { createPost, getDestinations } from '../services/destinations'

const CreatePost = () => {
  const navigate = useNavigate()
  const { register, handleSubmit, formState: { errors }, watch } = useForm()
  const [rating, setRating] = useState(5)
  const [loading, setLoading] = useState(false)

  const { data: destinationsData } = useQuery({
    queryKey: ['destinations'],
    queryFn: () => getDestinations({}).then(res => res.data)
  })

  const destinations = destinationsData?.results || []

  const createMutation = useMutation({
    mutationFn: (formData) => createPost(formData),
    onSuccess: (response) => {
      toast.success('Post created successfully!')
      navigate(`/posts/${response.data.id}`)
    },
    onError: (error) => {
      toast.error('Failed to create post')
      console.error(error)
    }
  })

  const onSubmit = async (data) => {
    setLoading(true)
    try {
      const formData = new FormData()
      formData.append('title', data.title)
      formData.append('content', data.content)
      formData.append('destination', data.destination)
      formData.append('rating', rating)
      
      if (data.featured_image?.[0]) {
        formData.append('featured_image', data.featured_image[0])
      }

      await createMutation.mutateAsync(formData)
    } catch (error) {
      console.error(error)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="max-w-3xl mx-auto">
        <h1 className="text-3xl font-bold mb-8">Create a New Post</h1>

        <form onSubmit={handleSubmit(onSubmit)} className="card">
          {/* Title */}
          <div className="mb-6">
            <label className="label">Title</label>
            <input
              type="text"
              placeholder="Give your post a title..."
              className="input"
              {...register('title', { required: 'Title is required' })}
            />
            {errors.title && (
              <p className="text-red-500 text-sm mt-1">{errors.title.message}</p>
            )}
          </div>

          {/* Destination */}
          <div className="mb-6">
            <label className="label">Destination</label>
            <select
              className="input"
              {...register('destination', { required: 'Please select a destination' })}
            >
              <option value="">Select a destination...</option>
              {destinations.map((dest) => (
                <option key={dest.id} value={dest.id}>
                  {dest.name} - {dest.city}, {dest.country}
                </option>
              ))}
            </select>
            {errors.destination && (
              <p className="text-red-500 text-sm mt-1">{errors.destination.message}</p>
            )}
          </div>

          {/* Rating */}
          <div className="mb-6">
            <label className="label">Your Rating</label>
            <div className="flex items-center space-x-2">
              {[1, 2, 3, 4, 5].map((star) => (
                <button
                  key={star}
                  type="button"
                  onClick={() => setRating(star)}
                  className="text-2xl transition-colors"
                >
                  <FaStar
                    className={star <= rating ? 'text-yellow-500' : 'text-gray-300'}
                  />
                </button>
              ))}
              <span className="ml-2 font-medium">{rating}/5</span>
            </div>
          </div>

          {/* Content */}
          <div className="mb-6">
            <label className="label">Content</label>
            <textarea
              rows="10"
              placeholder="Share your experience..."
              className="input"
              {...register('content', {
                required: 'Content is required',
                minLength: {
                  value: 50,
                  message: 'Content must be at least 50 characters'
                }
              })}
            />
            {errors.content && (
              <p className="text-red-500 text-sm mt-1">{errors.content.message}</p>
            )}
          </div>

          {/* Featured Image */}
          <div className="mb-6">
            <label className="label">Featured Image</label>
            <input
              type="file"
              accept="image/*"
              className="input"
              {...register('featured_image')}
            />
          </div>

          {/* Submit Button */}
          <div className="flex space-x-4">
            <button
              type="submit"
              disabled={loading}
              className="btn btn-primary flex-1"
            >
              {loading ? 'Creating...' : 'Create Post'}
            </button>
            <button
              type="button"
              onClick={() => navigate(-1)}
              className="btn btn-secondary"
            >
              Cancel
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}

export default CreatePost
