import { useState } from 'react'
import { useQuery } from '@tanstack/react-query'
import { FaSearch, FaFilter } from 'react-icons/fa'
import { getDestinations, getCategories } from '../services/destinations'
import DestinationCard from '../components/DestinationCard'

const Explore = () => {
  const [search, setSearch] = useState('')
  const [category, setCategory] = useState('')
  const [country, setCountry] = useState('')
  const [page, setPage] = useState(1)

  const { data: categories } = useQuery({
    queryKey: ['categories'],
    queryFn: () => getCategories().then(res => res.data)
  })

  const { data: destinationsData, isLoading, isFetching } = useQuery({
    queryKey: ['destinations', { search, category, country, page }],
    queryFn: () => getDestinations({ search, category, country, page }).then(res => res.data),
    keepPreviousData: true,
    staleTime: 15000,
  })

  const destinations = destinationsData?.results || []

  return (
    <div className="container mx-auto px-4 py-8">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-4xl font-bold mb-4">Explore Destinations</h1>
        <p className="text-gray-600">
          Discover amazing places around the world
        </p>
      </div>

      {/* Filters */}
      <div className="card mb-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          {/* Search */}
          <div className="md:col-span-2">
            <label className="label">Search</label>
            <div className="relative">
              <FaSearch className="absolute left-3 top-3 text-gray-400" />
              <input
                type="text"
                placeholder="Search destinations..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="input pl-10"
              />
            </div>
          </div>

          {/* Category Filter */}
          <div>
            <label className="label">Category</label>
            <select
              value={category}
              onChange={(e) => setCategory(e.target.value)}
              className="input"
            >
              <option value="">All Categories</option>
              {categories?.map((cat) => (
                <option key={cat.value} value={cat.value}>
                  {cat.label}
                </option>
              ))}
            </select>
          </div>

          {/* Country Filter */}
          <div>
            <label className="label">Country</label>
            <input
              type="text"
              placeholder="Country..."
              value={country}
              onChange={(e) => setCountry(e.target.value)}
              className="input"
            />
          </div>
        </div>
      </div>

      {/* Results */}
      {isLoading ? (
        <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-4 gap-6">
          {[...Array(8)].map((_, i) => (
            <div key={i} className="card h-64 animate-pulse bg-gray-200"></div>
          ))}
        </div>
      ) : destinations.length > 0 ? (
        <>
          <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-4 gap-6">
            {destinations.map((destination) => (
              <DestinationCard key={destination.id} destination={destination} />
            ))}
          </div>

          {/* Pagination Controls */}
          <div className="flex items-center justify-between mt-8">
            <button
              className="btn btn-secondary"
              disabled={!destinationsData?.previous || page === 1 || isFetching}
              onClick={() => setPage((p) => Math.max(1, p - 1))}
            >
              Previous
            </button>
            <div className="text-sm text-gray-600">
              Page {page} {isFetching && <span className="ml-2 text-primary-600">Loading…</span>}
            </div>
            <button
              className="btn btn-primary"
              disabled={!destinationsData?.next || isFetching}
              onClick={() => setPage((p) => p + 1)}
            >
              Next
            </button>
          </div>
        </>
      ) : (
        <div className="text-center py-12">
          <p className="text-gray-500 text-lg">No destinations found</p>
        </div>
      )}
    </div>
  )
}

export default Explore
