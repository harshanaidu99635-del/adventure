import api from './api'

// Destinations
export const getDestinations = (params) => api.get('/destinations/', { params })
export const getDestination = (id) => api.get(`/destinations/${id}/`)
export const createDestination = (data) => api.post('/destinations/', data)
export const updateDestination = (id, data) => api.put(`/destinations/${id}/`, data)
export const deleteDestination = (id) => api.delete(`/destinations/${id}/`)
export const getPopularDestinations = () => api.get('/destinations/popular/')
export const saveDestination = (id) => api.post(`/destinations/${id}/save/`)
export const unsaveDestination = (id) => api.post(`/destinations/${id}/unsave/`)
export const getSavedDestinations = () => api.get('/destinations/saved/')
export const getCategories = () => api.get('/destinations/categories/')

// Posts
export const getPosts = (params) => api.get('/posts/', { params })
export const getPost = (id) => api.get(`/posts/${id}/`)
export const createPost = (data) => api.post('/posts/', data, {
  headers: { 'Content-Type': 'multipart/form-data' }
})
export const updatePost = (id, data) => api.put(`/posts/${id}/`, data)
export const deletePost = (id) => api.delete(`/posts/${id}/`)
export const likePost = (id) => api.post(`/posts/${id}/like/`)
export const unlikePost = (id) => api.post(`/posts/${id}/unlike/`)
export const getPopularPosts = () => api.get('/posts/popular/')
export const getMyPosts = () => api.get('/posts/my_posts/')

// Comments
export const addComment = (postId, data) => api.post(`/posts/${postId}/add_comment/`, data)
export const getComments = (postId) => api.get(`/posts/${postId}/comments/`)
export const deleteComment = (id) => api.delete(`/posts/comments/${id}/`)

// Reviews
export const getReviews = (params) => api.get('/reviews/', { params })
export const getReview = (id) => api.get(`/reviews/${id}/`)
export const createReview = (data) => api.post('/reviews/', data)
export const updateReview = (id, data) => api.put(`/reviews/${id}/`, data)
export const deleteReview = (id) => api.delete(`/reviews/${id}/`)
export const markReviewHelpful = (id) => api.post(`/reviews/${id}/helpful/`)
export const unmarkReviewHelpful = (id) => api.post(`/reviews/${id}/unhelpful/`)
export const getReviewStats = (destinationId) => api.get('/reviews/destination_stats/', {
  params: { destination: destinationId }
})
export const getMyReviews = () => api.get('/reviews/my_reviews/')

// User
export const getCurrentUser = () => api.get('/accounts/current/')
export const getUserProfile = (username) => api.get(`/accounts/${username}/`)
export const updateProfile = (data) => api.patch('/accounts/profile/update/', data)
export const updateUserProfile = (data) => api.put('/accounts/me/', data)
