import { Link } from 'react-router-dom'
import { FaHeart, FaComment, FaEye, FaStar, FaTrash } from 'react-icons/fa'
import { format } from 'date-fns'
import { useAuth } from '../context/AuthContext'
import { useMutation, useQueryClient } from '@tanstack/react-query'
import { deletePost } from '../services/destinations'
import { toast } from 'react-toastify'

const PostCard = ({ post }) => {
  const { user } = useAuth()
  const queryClient = useQueryClient()

  const mutation = useMutation({
    mutationFn: (id) => deletePost(id),
    onSuccess: () => {
      toast.success('Post deleted successfully!')
      queryClient.invalidateQueries({ queryKey: ['userPosts'] })
      queryClient.invalidateQueries({ queryKey: ['posts'] })
    },
    onError: (error) => {
      toast.error(error.message || 'Failed to delete post.')
    }
  })

  const handleDelete = () => {
    if (window.confirm('Are you sure you want to delete this post?')) {
      mutation.mutate(post.id)
    }
  }

  return (
    <div className="card hover:shadow-xl transition-shadow duration-300 overflow-hidden p-0">
      {/* Image */}
      {post.featured_image && (
        <div className="relative h-56 bg-gray-200">
          <img
            src={post.featured_image}
            alt={post.title}
            className="w-full h-full object-cover"
            onError={(e) => {
              e.currentTarget.src = `https://source.unsplash.com/800x500/?travel,story`
              e.currentTarget.onerror = null
            }}
          />
        </div>
      )}

      {/* Content */}
      <div className="p-5">
        {/* Author & Date */}
        <div className="flex items-center space-x-3 mb-3">
          <div className="w-10 h-10 rounded-full bg-primary-100 flex items-center justify-center text-primary-600 font-semibold">
            {post.author_username?.[0]?.toUpperCase()}
          </div>
          <div className="flex-1">
            <Link 
              to={`/profile/${post.author_username}`}
              className="font-medium hover:text-primary-600"
            >
              {post.author_username}
            </Link>
            <p className="text-xs text-gray-500">
              {format(new Date(post.created_at), 'MMM dd, yyyy')}
            </p>
          </div>
          {/* Rating */}
          <div className="flex items-center space-x-1">
            <FaStar className="text-yellow-500" />
            <span className="font-semibold">{post.rating}</span>
          </div>
        </div>

        {/* Title */}
        <Link to={`/posts/${post.id}`}>
          <h3 className="font-bold text-xl mb-2 hover:text-primary-600 transition line-clamp-2">
            {post.title}
          </h3>
        </Link>

        {/* Destination */}
        <Link 
          to={`/destinations/${post.destination}`}
          className="text-sm text-primary-600 hover:underline mb-3 inline-block"
        >
          📍 {post.destination_name}
        </Link>

        {/* Content Preview */}
        <p className="text-gray-600 text-sm mb-4 line-clamp-3">
          {post.content}
        </p>

        {/* Stats */}
        <div className="flex items-center justify-between text-sm text-gray-500 border-t pt-3">
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-1">
              <FaHeart className={post.is_liked ? 'text-red-500' : ''} />
              <span>{post.likes_count ?? 0}</span>
            </div>
            <div className="flex items-center space-x-1">
              <FaComment />
              <span>{post.comments_count ?? 0}</span>
            </div>
            <div className="flex items-center space-x-1">
              <FaEye />
              <span>{post.views ?? 0}</span>
            </div>
          </div>
          <div className="flex items-center space-x-4">
            {user && user.id === post.author && (
              <button onClick={handleDelete} className="text-red-500 hover:text-red-700">
                <FaTrash />
              </button>
            )}
            <Link 
              to={`/posts/${post.id}`}
              className="text-primary-600 hover:underline font-medium"
            >
              Read more →
            </Link>
          </div>
        </div>
      </div>
    </div>
  )
}

export default PostCard
