import { MapContainer, TileLayer, Marker, Popup, useMap } from 'react-leaflet';
import { useState, useEffect } from 'react';
import 'leaflet/dist/leaflet.css';
import L from 'leaflet';

// Fix for default marker icon issue with webpack
delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://unpkg.com/leaflet@1.7.1/dist/images/marker-icon-2x.png',
  iconUrl: 'https://unpkg.com/leaflet@1.7.1/dist/images/marker-icon.png',
  shadowUrl: 'https://unpkg.com/leaflet@1.7.1/dist/images/marker-shadow.png',
});

const haversineDistance = (coords1, coords2) => {
  const toRad = (x) => (x * Math.PI) / 180;

  const R = 6371; // Earth radius in kilometers

  const dLat = toRad(coords2.lat - coords1.lat);
  const dLon = toRad(coords2.lng - coords1.lng);
  const lat1 = toRad(coords1.lat);
  const lat2 = toRad(coords2.lat);

  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.sin(dLon / 2) * Math.sin(dLon / 2) * Math.cos(lat1) * Math.cos(lat2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  const d = R * c;

  return d.toFixed(2); // Return distance in km, rounded to 2 decimal places
};

const RecenterAutomatically = ({lat, lng}) => {
    const map = useMap();
     useEffect(() => {
       map.setView([lat, lng]);
     }, [lat, lng, map]);
     return null;
}

const LocationMap = ({ destination }) => {
  const [userLocation, setUserLocation] = useState(null);
  const [distance, setDistance] = useState(null);

  const destinationCoords = {
    lat: parseFloat(destination.latitude),
    lng: parseFloat(destination.longitude),
  };

  useEffect(() => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          const { latitude, longitude } = position.coords;
          const currentUserLocation = { lat: latitude, lng: longitude };
          setUserLocation(currentUserLocation);
          const dist = haversineDistance(currentUserLocation, destinationCoords);
          setDistance(dist);
        },
        () => {
          console.error("Could not get user location.");
        }
      );
    }
  }, [destination.latitude, destination.longitude]);

  if (!destination.latitude || !destination.longitude) {
    return <p>Location data is not available for this destination.</p>;
  }

  return (
    <div className="mt-8">
      <h3 className="text-2xl font-bold text-gray-800 mb-4">Location Map</h3>
      {distance && <p className="mb-4 text-lg">You are approximately <strong>{distance} km</strong> away from {destination.name}.</p>}
      <div className="h-96 w-full rounded-lg overflow-hidden shadow-lg">
        <MapContainer center={[destinationCoords.lat, destinationCoords.lng]} zoom={userLocation ? 10 : 5} scrollWheelZoom={false} style={{ height: '100%', width: '100%' }}>
          <TileLayer
            attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
            url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
          />
          <Marker position={[destinationCoords.lat, destinationCoords.lng]}>
            <Popup>{destination.name}</Popup>
          </Marker>
          {userLocation && (
            <Marker position={[userLocation.lat, userLocation.lng]} icon={L.icon({ iconUrl: 'https://unpkg.com/leaflet@1.7.1/dist/images/marker-icon.png', iconSize: [25, 41], iconAnchor: [12, 41] })}>
              <Popup>Your Location</Popup>
            </Marker>
          )}
          {userLocation && <RecenterAutomatically lat={(userLocation.lat + destinationCoords.lat) / 2} lng={(userLocation.lng + destinationCoords.lng) / 2} />}
        </MapContainer>
      </div>
    </div>
  );
};

export default LocationMap;
