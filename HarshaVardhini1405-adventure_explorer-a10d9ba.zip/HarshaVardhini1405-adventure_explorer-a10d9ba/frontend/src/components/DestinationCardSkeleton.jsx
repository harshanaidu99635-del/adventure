const DestinationCardSkeleton = () => {
  return (
    <div className="card p-0 overflow-hidden animate-pulse">
      {/* Image */}
      <div className="h-56 bg-gray-300"></div>

      {/* Content */}
      <div className="p-5">
        {/* Author & Date */}
        <div className="flex items-center space-x-3 mb-3">
          <div className="w-10 h-10 rounded-full bg-gray-300"></div>
          <div className="flex-1">
            <div className="h-4 bg-gray-300 rounded w-3/4 mb-2"></div>
            <div className="h-3 bg-gray-300 rounded w-1/2"></div>
          </div>
        </div>

        {/* Title */}
        <div className="h-6 bg-gray-300 rounded w-5/6 mb-2"></div>
        
        {/* Destination */}
        <div className="h-4 bg-gray-300 rounded w-1/3 mb-3"></div>

        {/* Content Preview */}
        <div className="space-y-2 mb-4">
          <div className="h-3 bg-gray-300 rounded"></div>
          <div className="h-3 bg-gray-300 rounded"></div>
          <div className="h-3 bg-gray-300 rounded w-11/12"></div>
        </div>

        {/* Stats */}
        <div className="flex items-center justify-between border-t pt-3">
          <div className="flex items-center space-x-4">
            <div className="h-4 w-8 bg-gray-300 rounded"></div>
            <div className="h-4 w-8 bg-gray-300 rounded"></div>
            <div className="h-4 w-8 bg-gray-300 rounded"></div>
          </div>
          <div className="h-4 w-20 bg-gray-300 rounded"></div>
        </div>
      </div>
    </div>
  );
};

export default DestinationCardSkeleton;
