const ProfilePageSkeleton = () => {
  return (
    <div className="container mx-auto px-4 py-8 animate-pulse">
      {/* Profile Header */}
      <div className="card mb-8">
        <div className="flex items-start space-x-6">
          {/* Avatar */}
          <div className="w-24 h-24 rounded-full bg-gray-300"></div>

          {/* Info */}
          <div className="flex-1">
            <div className="h-8 bg-gray-300 rounded w-1/3 mb-3"></div>
            <div className="h-4 bg-gray-300 rounded w-1/4 mb-4"></div>
            
            <div className="space-y-2 mb-4">
              <div className="h-4 bg-gray-300 rounded"></div>
              <div className="h-4 bg-gray-300 rounded w-5/6"></div>
            </div>

            <div className="flex flex-wrap gap-4">
              <div className="h-5 bg-gray-300 rounded w-24"></div>
              <div className="h-5 bg-gray-300 rounded w-24"></div>
              <div className="h-5 bg-gray-300 rounded w-32"></div>
            </div>
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-3 gap-4 mt-6 pt-6 border-t border-gray-200">
          <div className="text-center">
            <div className="h-7 bg-gray-300 rounded w-10 mx-auto mb-2"></div>
            <div className="h-4 bg-gray-300 rounded w-12 mx-auto"></div>
          </div>
          <div className="text-center">
            <div className="h-7 bg-gray-300 rounded w-10 mx-auto mb-2"></div>
            <div className="h-4 bg-gray-300 rounded w-16 mx-auto"></div>
          </div>
          <div className="text-center">
            <div className="h-7 bg-gray-300 rounded w-10 mx-auto mb-2"></div>
            <div className="h-4 bg-gray-300 rounded w-12 mx-auto"></div>
          </div>
        </div>
      </div>

      {/* Tab Navigation */}
      <div className="mb-8 border-b border-gray-200">
        <div className="flex space-x-8">
          <div className="h-10 bg-gray-300 rounded-t w-24"></div>
          <div className="h-10 bg-gray-300 rounded-t w-36"></div>
          <div className="h-10 bg-gray-300 rounded-t w-28"></div>
        </div>
      </div>

      {/* Tab Content */}
      <div>
        <div className="h-8 bg-gray-300 rounded w-1/4 mb-6"></div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[...Array(3)].map((_, i) => (
            <div key={i} className="h-72 bg-gray-300 rounded-lg"></div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default ProfilePageSkeleton;
