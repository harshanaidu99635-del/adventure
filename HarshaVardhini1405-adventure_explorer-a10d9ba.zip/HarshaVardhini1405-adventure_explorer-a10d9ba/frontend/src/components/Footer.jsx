import { Link } from 'react-router-dom'
import { FaGlobeAmericas, FaGithub, FaTwitter, FaInstagram } from 'react-icons/fa'

const Footer = () => {
  return (
    <footer className="bg-gray-800 text-white mt-12">
      <div className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Brand */}
          <div>
            <div className="flex items-center space-x-2 mb-4">
              <FaGlobeAmericas className="text-2xl text-primary-400" />
              <span className="font-bold text-xl">Traveller</span>
            </div>
            <p className="text-gray-400 text-sm">
              Discover, explore, and share your travel experiences with the world.
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="font-semibold mb-4">Quick Links</h3>
            <ul className="space-y-2">
              <li>
                <Link to="/explore" className="text-gray-400 hover:text-white transition">
                  Explore Destinations
                </Link>
              </li>
              <li>
                <Link to="/posts/create" className="text-gray-400 hover:text-white transition">
                  Create Post
                </Link>
              </li>
              <li>
                <Link to="/dashboard" className="text-gray-400 hover:text-white transition">
                  Dashboard
                </Link>
              </li>
            </ul>
          </div>

          {/* Categories */}
          <div>
            <h3 className="font-semibold mb-4">Categories</h3>
            <ul className="space-y-2 text-sm">
              <li className="text-gray-400">Mountains</li>
              <li className="text-gray-400">Beaches</li>
              <li className="text-gray-400">Historical Sites</li>
              <li className="text-gray-400">Cities</li>
            </ul>
          </div>

          {/* Social */}
          <div>
            <h3 className="font-semibold mb-4">Follow Us</h3>
            <div className="flex space-x-4">
              <a href="#" className="text-gray-400 hover:text-white transition">
                <FaGithub className="text-xl" />
              </a>
              <a href="#" className="text-gray-400 hover:text-white transition">
                <FaTwitter className="text-xl" />
              </a>
              <a href="#" className="text-gray-400 hover:text-white transition">
                <FaInstagram className="text-xl" />
              </a>
            </div>
          </div>
        </div>

        <div className="border-t border-gray-700 mt-8 pt-6 text-center text-gray-400 text-sm">
          <p>&copy; 2025 Traveller. All rights reserved.</p>
        </div>
      </div>
    </footer>
  )
}

export default Footer
