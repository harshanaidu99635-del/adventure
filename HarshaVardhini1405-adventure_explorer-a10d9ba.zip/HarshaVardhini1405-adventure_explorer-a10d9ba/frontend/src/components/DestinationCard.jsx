import { Link } from 'react-router-dom'
import { FaMapMarkerAlt, FaStar, FaEye } from 'react-icons/fa'

const DestinationCard = ({ destination }) => {
  const fallbackSrc = `https://source.unsplash.com/600x400/?${encodeURIComponent(destination.name || 'travel')}`
  const handleImgError = (e) => {
    e.currentTarget.src = fallbackSrc
    e.currentTarget.onerror = null
  }
  return (
    <Link to={`/destinations/${destination.id}`}>
      <div className="card hover:shadow-xl transition-shadow duration-300 overflow-hidden p-0">
        {/* Image */}
        <div className="relative h-48 bg-gray-200">
          {destination.image_present || destination.image_past ? (
            <img
              src={destination.image_present || destination.image_past}
              alt={destination.name}
              className="w-full h-full object-cover"
              onError={handleImgError}
              loading="lazy"
            />
          ) : (
            <div className="w-full h-full flex items-center justify-center text-gray-400">
              <FaMapMarkerAlt className="text-4xl" />
            </div>
          )}
          {/* Category Badge */}
          <span className="absolute top-2 right-2 bg-primary-600 text-white text-xs px-3 py-1 rounded-full">
            {destination.category}
          </span>
        </div>

        {/* Content */}
        <div className="p-4">
          <h3 className="font-bold text-lg mb-2 line-clamp-2">{destination.name}</h3>
          
          <div className="flex items-center text-sm text-gray-600 mb-3">
            <FaMapMarkerAlt className="mr-1" />
            <span>{destination.city}, {destination.country}</span>
          </div>

          {/* Stats */}
          <div className="flex items-center justify-between text-sm">
            <div className="flex items-center space-x-1">
              <FaStar className="text-yellow-500" />
              <span className="font-semibold">{destination.average_rating ?? 0}</span>
              <span className="text-gray-500">({destination.total_reviews ?? 0})</span>
            </div>
            <div className="flex items-center space-x-1 text-gray-500">
              <FaEye />
              <span>{destination.views ?? 0}</span>
            </div>
          </div>
        </div>
      </div>
    </Link>
  )
}

export default DestinationCard
