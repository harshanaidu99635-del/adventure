import { useState, useEffect } from 'react'
import { useMutation, useQueryClient } from '@tanstack/react-query'
import { updateUserProfile } from '../services/destinations'
import { FaTimes } from 'react-icons/fa'

const EditProfileModal = ({ user, onClose }) => {
  const [formData, setFormData] = useState({
    first_name: '',
    last_name: '',
    profile: {
      bio: '',
      location: '',
      website: ''
    }
  });
  const [profilePicture, setProfilePicture] = useState(null);
  const [preview, setPreview] = useState(null);

  useEffect(() => {
    if (user) {
      setFormData({
        first_name: user.first_name || '',
        last_name: user.last_name || '',
        profile: {
          bio: user.profile?.bio || '',
          location: user.profile?.location || '',
          website: user.profile?.website || ''
        }
      });
      if (user.profile?.profile_picture) {
        setPreview(user.profile.profile_picture);
      }
    }
  }, [user]);

  const queryClient = useQueryClient();

  const mutation = useMutation({
    mutationFn: (updatedData) => updateUserProfile(updatedData),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['userProfile', user.username] });
      onClose();
    },
    onError: (error) => {
      console.error('Error updating profile:', error);
      // You could set an error state here to inform the user
    }
  });

  const handlePictureChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      setProfilePicture(file);
      const reader = new FileReader();
      reader.onloadend = () => {
        setPreview(reader.result);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    if (name in formData.profile) {
      setFormData(prev => ({
        ...prev,
        profile: { ...prev.profile, [name]: value }
      }));
    } else {
      setFormData(prev => ({ ...prev, [name]: value }));
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const submissionData = new FormData();
    submissionData.append('first_name', formData.first_name);
    submissionData.append('last_name', formData.last_name);
    submissionData.append('profile.bio', formData.profile.bio);
    submissionData.append('profile.location', formData.profile.location);
    submissionData.append('profile.website', formData.profile.website);
    if (profilePicture) {
      submissionData.append('profile.profile_picture', profilePicture);
    }
    
    mutation.mutate(submissionData);
  };

  if (!user) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex justify-center items-center">
      <div className="bg-white rounded-lg shadow-xl p-8 w-full max-w-md m-4">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-bold">Edit Profile</h2>
          <button onClick={onClose} className="text-gray-500 hover:text-gray-800">
            <FaTimes size={20} />
          </button>
        </div>
        <form onSubmit={handleSubmit}>
          <div className="flex items-center space-x-4 mb-6">
            <div className="w-24 h-24 rounded-full bg-gray-200 flex-shrink-0">
              {preview ? (
                <img src={preview} alt="Profile Preview" className="w-full h-full rounded-full object-cover" />
              ) : (
                <div className="w-full h-full rounded-full bg-primary-100 flex items-center justify-center text-primary-600 font-bold text-4xl">
                  {user?.username?.[0]?.toUpperCase()}
                </div>
              )}
            </div>
            <div className="flex-grow">
              <label htmlFor="profile-picture-upload" className="btn btn-secondary cursor-pointer">
                Change Picture
              </label>
              <input
                id="profile-picture-upload"
                type="file"
                accept="image/*"
                onChange={handlePictureChange}
                className="hidden"
              />
              <p className="text-xs text-gray-500 mt-2">JPG, PNG, or GIF. 2MB max.</p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
            <input
              type="text"
              name="first_name"
              value={formData.first_name}
              onChange={handleChange}
              placeholder="First Name"
              className="input"
            />
            <input
              type="text"
              name="last_name"
              value={formData.last_name}
              onChange={handleChange}
              placeholder="Last Name"
              className="input"
            />
          </div>
          <textarea
            name="bio"
            value={formData.profile.bio}
            onChange={handleChange}
            placeholder="Your Bio"
            className="input w-full mb-4"
            rows="3"
          ></textarea>
          <input
            type="text"
            name="location"
            value={formData.profile.location}
            onChange={handleChange}
            placeholder="Location"
            className="input w-full mb-4"
          />
          <input
            type="url"
            name="website"
            value={formData.profile.website}
            onChange={handleChange}
            placeholder="https://your-website.com"
            className="input w-full mb-4"
          />
          <div className="flex justify-end space-x-4">
            <button type="button" onClick={onClose} className="btn btn-secondary">
              Cancel
            </button>
            <button type="submit" className="btn btn-primary" disabled={mutation.isLoading}>
              {mutation.isLoading ? 'Saving...' : 'Save Changes'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default EditProfileModal
