import { FaStar } from 'react-icons/fa'
import { format } from 'date-fns'

const ReviewCard = ({ review, onHelpful }) => {
  return (
    <div className="border-b border-gray-200 py-4 last:border-b-0">
      {/* Header */}
      <div className="flex items-start justify-between mb-3">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 rounded-full bg-primary-100 flex items-center justify-center text-primary-600 font-semibold">
            {review.user_username?.[0]?.toUpperCase()}
          </div>
          <div>
            <p className="font-medium">{review.user_username}</p>
            <p className="text-xs text-gray-500">
              {format(new Date(review.created_at), 'MMM dd, yyyy')}
            </p>
          </div>
        </div>
        {/* Rating */}
        <div className="flex items-center space-x-1">
          {[...Array(5)].map((_, index) => (
            <FaStar
              key={index}
              className={index < review.rating ? 'text-yellow-500' : 'text-gray-300'}
            />
          ))}
        </div>
      </div>

      {/* Title */}
      <h4 className="font-semibold text-lg mb-2">{review.title}</h4>

      {/* Review Text */}
      <p className="text-gray-700 mb-3">{review.review_text}</p>

      {/* Visit Date */}
      {review.visit_date && (
        <p className="text-sm text-gray-500 mb-2">
          Visited: {format(new Date(review.visit_date), 'MMMM yyyy')}
        </p>
      )}

      {/* Helpful Button */}
      <button
        onClick={() => onHelpful && onHelpful(review.id)}
        className={`text-sm ${
          review.is_helpful ? 'text-primary-600' : 'text-gray-500'
        } hover:text-primary-600 transition`}
      >
        👍 Helpful ({review.helpful_count})
      </button>
    </div>
  )
}

export default ReviewCard
