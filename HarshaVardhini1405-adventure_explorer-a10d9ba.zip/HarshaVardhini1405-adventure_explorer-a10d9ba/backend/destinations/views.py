from rest_framework import viewsets, status, filters, generics
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticatedOrReadOnly, IsAuthenticated
from django_filters.rest_framework import DjangoFilterBackend
from .models import Destination, DestinationImage, SavedDestination
from .serializers import (
    DestinationListSerializer,
    DestinationDetailSerializer,
    DestinationCreateUpdateSerializer,
    DestinationImageSerializer,
    SavedDestinationSerializer
)
from rest_framework.permissions import IsAuthenticated

class DestinationViewSet(viewsets.ModelViewSet):
    """ViewSet for Destination CRUD operations."""
    
    queryset = Destination.objects.filter(is_active=True)
    permission_classes = [IsAuthenticatedOrReadOnly]
    filter_backends = [DjangoFilterBackend, filters.SearchFilter, filters.OrderingFilter]
    filterset_fields = ['category', 'country', 'city']
    search_fields = ['name', 'description', 'city', 'country']
    ordering_fields = ['average_rating', 'total_reviews', 'views', 'created_at']
    ordering = ['-created_at']
    
    def get_serializer_class(self):
        if self.action == 'list':
            return DestinationListSerializer
        elif self.action in ['create', 'update', 'partial_update']:
            return DestinationCreateUpdateSerializer
        return DestinationDetailSerializer
    
    def perform_create(self, serializer):
        serializer.save(created_by=self.request.user)
    
    def retrieve(self, request, *args, **kwargs):
        instance = self.get_object()
        # Increment view count
        instance.views += 1
        instance.save(update_fields=['views'])
        serializer = self.get_serializer(instance)
        return Response(serializer.data)
    
    @action(detail=True, methods=['post'], permission_classes=[IsAuthenticated])
    def save(self, request, pk=None):
        """Save/bookmark a destination."""
        destination = self.get_object()
        saved, created = SavedDestination.objects.get_or_create(
            user=request.user,
            destination=destination
        )
        if created:
            return Response({'status': 'destination saved'}, status=status.HTTP_201_CREATED)
        return Response({'status': 'already saved'}, status=status.HTTP_200_OK)
    
    @action(detail=True, methods=['post'], permission_classes=[IsAuthenticated])
    def unsave(self, request, pk=None):
        """Remove destination from saved."""
        destination = self.get_object()
        deleted = SavedDestination.objects.filter(
            user=request.user,
            destination=destination
        ).delete()
        if deleted[0] > 0:
            return Response({'status': 'destination unsaved'}, status=status.HTTP_200_OK)
        return Response({'status': 'not saved'}, status=status.HTTP_404_NOT_FOUND)
    
    @action(detail=False, methods=['get'], permission_classes=[IsAuthenticated])
    def saved(self, request):
        """Get user's saved destinations."""
        saved_destinations = SavedDestination.objects.filter(user=request.user)
        page = self.paginate_queryset(saved_destinations)
        if page is not None:
            serializer = SavedDestinationSerializer(page, many=True)
            return self.get_paginated_response(serializer.data)
        serializer = SavedDestinationSerializer(saved_destinations, many=True)
        return Response(serializer.data)
    
    @action(detail=False, methods=['get'])
    def popular(self, request):
        """Get popular destinations by average rating."""
        popular = self.queryset.order_by('-average_rating', '-total_reviews')[:10]
        serializer = DestinationListSerializer(popular, many=True)
        return Response(serializer.data)
    
    @action(detail=False, methods=['get'])
    def categories(self, request):
        """Get all available categories."""
        categories = [{'value': cat[0], 'label': cat[1]} 
                     for cat in Destination.CATEGORY_CHOICES]
        return Response(categories)


class DestinationImageViewSet(viewsets.ModelViewSet):
    """ViewSet for managing destination images."""
    
    queryset = DestinationImage.objects.all()
    serializer_class = DestinationImageSerializer
    permission_classes = [IsAuthenticatedOrReadOnly]
    
    def get_queryset(self):
        queryset = super().get_queryset()
        destination_id = self.request.query_params.get('destination', None)
        if destination_id:
            queryset = queryset.filter(destination_id=destination_id)
        return queryset
    
    def perform_create(self, serializer):
        serializer.save(uploaded_by=self.request.user)


class SavedDestinationListView(generics.ListAPIView):
    serializer_class = SavedDestinationSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        user_id = self.request.query_params.get('user_id')
        if user_id and self.request.user.is_staff: # Allow staff to view others' saved lists
             return SavedDestination.objects.filter(user__id=user_id)
        return SavedDestination.objects.filter(user=self.request.user)


class SavedDestinationCreateView(generics.CreateAPIView):
    serializer_class = SavedDestinationSerializer
    permission_classes = [IsAuthenticated]

    def create(self, request, *args, **kwargs):
        destination = self.get_object()
        saved, created = SavedDestination.objects.get_or_create(
            user=request.user,
            destination=destination
        )
        if created:
            return Response({'status': 'destination saved'}, status=status.HTTP_201_CREATED)
        return Response({'status': 'already saved'}, status=status.HTTP_200_OK)
