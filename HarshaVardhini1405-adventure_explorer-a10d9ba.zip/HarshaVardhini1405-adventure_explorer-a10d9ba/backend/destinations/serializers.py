from rest_framework import serializers
from .models import Destination, DestinationImage, SavedDestination


class DestinationImageSerializer(serializers.ModelSerializer):
    uploaded_by_username = serializers.CharField(source='uploaded_by.username', read_only=True)
    
    class Meta:
        model = DestinationImage
        fields = ['id', 'image', 'caption', 'uploaded_by', 'uploaded_by_username', 'uploaded_at']
        read_only_fields = ['uploaded_by', 'uploaded_at']


class DestinationListSerializer(serializers.ModelSerializer):
    """Serializer for listing destinations (less detail)."""
    created_by_username = serializers.CharField(source='created_by.username', read_only=True)
    
    class Meta:
        model = Destination
        fields = ['id', 'name', 'city', 'country', 'category', 'image_present', 'image_past',
                  'average_rating', 'total_reviews', 'views', 'created_by_username']


class DestinationDetailSerializer(serializers.ModelSerializer):
    """Serializer for destination details (full info)."""
    images = DestinationImageSerializer(many=True, read_only=True)
    created_by_username = serializers.CharField(source='created_by.username', read_only=True)
    is_saved = serializers.SerializerMethodField()
    
    class Meta:
        model = Destination
        fields = ['id', 'name', 'description', 'country', 'state', 'city', 
                  'category', 'latitude', 'longitude', 'image_present', 'image_past', 'images',
                  'average_rating', 'total_reviews', 'views', 'created_by', 
                  'created_by_username', 'created_at', 'updated_at', 'is_saved']
        read_only_fields = ['average_rating', 'total_reviews', 'views', 'created_at', 'updated_at']
    
    def get_is_saved(self, obj):
        request = self.context.get('request')
        if request and request.user.is_authenticated:
            return SavedDestination.objects.filter(user=request.user, destination=obj).exists()
        return False


class DestinationCreateUpdateSerializer(serializers.ModelSerializer):
    """Serializer for creating/updating destinations."""
    
    class Meta:
        model = Destination
        fields = ['name', 'description', 'country', 'state', 'city', 'category',
                  'latitude', 'longitude', 'image_present', 'image_past']


class SavedDestinationSerializer(serializers.ModelSerializer):
    destination = DestinationListSerializer(read_only=True)
    
    class Meta:
        model = SavedDestination
        fields = ['id', 'destination', 'saved_at']
        read_only_fields = ['saved_at']
