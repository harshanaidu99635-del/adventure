from django.contrib import admin
from .models import Destination, DestinationImage, SavedDestination


@admin.register(Destination)
class DestinationAdmin(admin.ModelAdmin):
    list_display = ['name', 'city', 'country', 'category', 'average_rating', 'total_reviews', 'is_active']
    list_filter = ['category', 'country', 'is_active', 'created_at']
    search_fields = ['name', 'city', 'country', 'description']
    readonly_fields = ['average_rating', 'total_reviews', 'views', 'created_at', 'updated_at']
    fieldsets = (
        ('Basic Information', {
            'fields': ('name', 'description', 'category', 'main_image')
        }),
        ('Location', {
            'fields': ('country', 'state', 'city', 'latitude', 'longitude')
        }),
        ('Statistics', {
            'fields': ('average_rating', 'total_reviews', 'views')
        }),
        ('Metadata', {
            'fields': ('created_by', 'is_active', 'created_at', 'updated_at')
        }),
    )


@admin.register(DestinationImage)
class DestinationImageAdmin(admin.ModelAdmin):
    list_display = ['destination', 'caption', 'uploaded_by', 'uploaded_at']
    list_filter = ['uploaded_at']
    search_fields = ['destination__name', 'caption']


@admin.register(SavedDestination)
class SavedDestinationAdmin(admin.ModelAdmin):
    list_display = ['user', 'destination', 'saved_at']
    list_filter = ['saved_at']
    search_fields = ['user__username', 'destination__name']
