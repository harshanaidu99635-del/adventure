from django.db import models
from django.contrib.auth import get_user_model

User = get_user_model()


class Destination(models.Model):
    """Tourist destination/spot model."""
    
    CATEGORY_CHOICES = [
        ('mountain', 'Mountain'),
        ('beach', 'Beach'),
        ('historical', 'Historical'),
        ('city', 'City'),
        ('nature', 'Nature'),
        ('adventure', 'Adventure'),
        ('cultural', 'Cultural'),
        ('religious', 'Religious'),
        ('wildlife', 'Wildlife'),
        ('other', 'Other'),
    ]
    
    name = models.CharField(max_length=200)
    description = models.TextField()
    country = models.CharField(max_length=100)
    state = models.CharField(max_length=100, blank=True)
    city = models.CharField(max_length=100)
    category = models.CharField(max_length=20, choices=CATEGORY_CHOICES, default='other')
    
    # Location coordinates for map
    latitude = models.DecimalField(max_digits=9, decimal_places=6, null=True, blank=True)
    longitude = models.DecimalField(max_digits=9, decimal_places=6, null=True, blank=True)
    
    # Images (store absolute URLs so we can use remote image sources for demo data)
    image_present = models.URLField(max_length=500, blank=True, null=True)
    image_past = models.URLField(max_length=500, blank=True, null=True)
    
    # Stats
    average_rating = models.DecimalField(max_digits=3, decimal_places=2, default=0.0)
    total_reviews = models.IntegerField(default=0)
    views = models.IntegerField(default=0)
    
    # Metadata
    created_by = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, related_name='created_destinations')
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    is_active = models.BooleanField(default=True)
    
    class Meta:
        ordering = ['-created_at']
        indexes = [
            models.Index(fields=['country', 'city']),
            models.Index(fields=['category']),
            models.Index(fields=['-average_rating']),
        ]
    
    def __str__(self):
        return f"{self.name}, {self.city}, {self.country}"
    
    def update_rating(self):
        """Update average rating based on reviews."""
        from reviews.models import Review
        reviews = Review.objects.filter(destination=self)
        if reviews.exists():
            self.average_rating = reviews.aggregate(models.Avg('rating'))['rating__avg']
            self.total_reviews = reviews.count()
            self.save(update_fields=['average_rating', 'total_reviews'])


class DestinationImage(models.Model):
    """Additional images for destinations."""
    
    destination = models.ForeignKey(Destination, on_delete=models.CASCADE, related_name='images')
    image = models.ImageField(upload_to='destinations/gallery/')
    caption = models.CharField(max_length=200, blank=True)
    uploaded_by = models.ForeignKey(User, on_delete=models.SET_NULL, null=True)
    uploaded_at = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        ordering = ['-uploaded_at']
    
    def __str__(self):
        return f"Image for {self.destination.name}"


class SavedDestination(models.Model):
    """User's saved/favorite destinations."""
    
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='saved_destinations')
    destination = models.ForeignKey(Destination, on_delete=models.CASCADE, related_name='saved_by')
    saved_at = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        unique_together = ['user', 'destination']
        ordering = ['-saved_at']
    
    def __str__(self):
        return f"{self.user.username} saved {self.destination.name}"
