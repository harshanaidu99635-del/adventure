"""
Management command to populate the database with sample data.
Run with: python manage.py populate_data
"""
from django.core.management.base import BaseCommand
import os
import json
from django.contrib.auth import get_user_model
from destinations.models import Destination
from posts.models import Post
from reviews.models import Review

User = get_user_model()


class Command(BaseCommand):
    help = 'Populates database with sample travel data'

    def handle(self, *args, **kwargs):
        self.stdout.write('Populating database with sample data...')

        # Create sample users if they don't exist
        users = []
        for i in range(1, 4):
            email = f'user{i}@example.com'
            if not User.objects.filter(email=email).exists():
                user = User.objects.create_user(
                    email=email,
                    username=f'traveler{i}',
                    password='password123',
                    first_name=f'John{i}',
                    last_name='Doe'
                )
                users.append(user)
                self.stdout.write(f'Created user: {user.username}')

        if not users:
            users = list(User.objects.all()[:3])

        # Sample destinations (baseline set kept for local demo)
        destinations_data = [
            # India
            {
                'name': 'Charminar',
                'description': 'A 16th-century mosque with 4 grand arches and 4 minarets, located in the heart of Hyderabad.',
                'country': 'India',
                'city': 'Hyderabad',
                'category': 'historical',
                'latitude': 17.3616,
                'longitude': 78.4747,
                'image_present': 'https://images.unsplash.com/photo-1513836279014-a89f7a76ae86?auto=format&fit=crop&w=1200&q=80',
                'image_past': 'https://images.unsplash.com/photo-1513521772822-4ba4e09c5ff7?auto=format&fit=crop&w=1200&q=80',
            },
            {
                'name': 'Golconda Fort',
                'description': 'A fortified citadel and early capital city of the Qutb Shahi dynasty, located in Hyderabad.',
                'country': 'India',
                'city': 'Hyderabad',
                'category': 'historical',
                'latitude': 17.3833,
                'longitude': 78.4011,
                'image_present': 'https://images.unsplash.com/photo-1604065306134-b8e17c9fbad5?auto=format&fit=crop&w=1200&q=80',
                'image_past': 'https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?auto=format&fit=crop&w=1200&q=80',
            },
            {
                'name': 'Lalbagh Botanical Garden',
                'description': 'A nationally and internationally renowned centre for botanical artwork, scientific study of plants and also conservation of plants.',
                'country': 'India',
                'city': 'Bangalore',
                'category': 'nature',
                'latitude': 12.9507,
                'longitude': 77.5848,
                'image_present': 'https://images.unsplash.com/photo-1512453979798-5ea266f8880c?auto=format&fit=crop&w=1200&q=80',
                'image_past': 'https://images.unsplash.com/photo-1511268559489-6dd0e69e9a77?auto=format&fit=crop&w=1200&q=80',
            },
            {
                'name': 'Bangalore Palace',
                'description': 'A royal palace located in Bengaluru, Karnataka, India, in an area that was owned by Rev. J. Garrett.',
                'country': 'India',
                'city': 'Bangalore',
                'category': 'historical',
                'latitude': 12.9988,
                'longitude': 77.5921,
                'image_present': 'https://images.unsplash.com/photo-1557655838-8615e0b0466f?auto=format&fit=crop&w=1200&q=80',
                'image_past': 'https://images.unsplash.com/photo-1534578297767-257086d11781?auto=format&fit=crop&w=1200&q=80',
            },
            {
                'name': 'Gateway of India',
                'description': 'An arch-monument built in the early twentieth century in the city of Mumbai, in the Indian state of Maharashtra.',
                'country': 'India',
                'city': 'Mumbai',
                'category': 'historical',
                'latitude': 18.9220,
                'longitude': 72.8347,
                'image_present': 'https://images.unsplash.com/photo-1526129318478-62ed807ebdf9?auto=format&fit=crop&w=1200&q=80',
                'image_past': 'https://images.unsplash.com/photo-1513521772822-4ba4e09c5ff7?auto=format&fit=crop&w=1200&q=80',
            },
            {
                'name': 'Marine Drive',
                'description': 'A 3.6-kilometre-long promenade along the Netaji Subhash Chandra Bose Road in South Mumbai.',
                'country': 'India',
                'city': 'Mumbai',
                'category': 'city',
                'latitude': 18.9432,
                'longitude': 72.8235,
                'image_present': 'https://images.unsplash.com/photo-1605749131075-0afd00f6f26b?auto=format&fit=crop&w=1200&q=80',
                'image_past': 'https://images.unsplash.com/photo-1477587458883-47145ed94245?auto=format&fit=crop&w=1200&q=80',
            },
            {
                'name': 'Marina Beach',
                'description': 'A natural urban beach in Chennai, Tamil Nadu, India, along the Bay of Bengal.',
                'country': 'India',
                'city': 'Chennai',
                'category': 'beach',
                'latitude': 13.059,
                'longitude': 80.2825,
                'image_present': 'https://images.unsplash.com/photo-1602878244485-68b806f8b0fc?auto=format&fit=crop&w=1200&q=80',
                'image_past': 'https://images.unsplash.com/photo-1469474968028-56623f02e42e?auto=format&fit=crop&w=1200&q=80',
            },
            {
                'name': 'Mahabalipuram',
                'description': 'A town on a strip of land between the Bay of Bengal and the Great Salt Lake, in the south Indian state of Tamil Nadu.',
                'country': 'India',
                'city': 'Mahabalipuram',
                'category': 'historical',
                'latitude': 12.6266,
                'longitude': 80.1924,
                'image_present': 'https://images.unsplash.com/photo-1598100015256-7b4656b41a2f?auto=format&fit=crop&w=1200&q=80',
                'image_past': 'https://images.unsplash.com/photo-1587037040466-d1c2996eea2b?auto=format&fit=crop&w=1200&q=80',
            },
            {
                'name': 'India Gate',
                'description': 'A war memorial located astride the Rajpath, on the eastern edge of the "ceremonial axis" of New Delhi.',
                'country': 'India',
                'city': 'Delhi',
                'category': 'historical',
                'latitude': 28.6129,
                'longitude': 77.2295,
                'image_present': 'https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?auto=format&fit=crop&w=1200&q=80',
                'image_past': 'https://images.unsplash.com/photo-1526404382420-8811f9c97d85?auto=format&fit=crop&w=1200&q=80',
            },
            {
                'name': 'Qutub Minar',
                'description': 'A minaret and "victory tower" that forms part of the Qutb complex, a UNESCO World Heritage Site in the Mehrauli area of Delhi.',
                'country': 'India',
                'city': 'Delhi',
                'category': 'historical',
                'latitude': 28.5245,
                'longitude': 77.1855,
                'image_present': 'https://images.unsplash.com/photo-1533106418989-88406c7cc8bb?auto=format&fit=crop&w=1200&q=80',
                'image_past': 'https://images.unsplash.com/photo-1511268559489-6dd0e69e9a77?auto=format&fit=crop&w=1200&q=80',
            },
            {
                'name': 'Alleppey Backwaters',
                'description': 'A network of tranquil canals and lagoons in Kerala, famous for its houseboat cruises.',
                'country': 'India',
                'city': 'Alleppey',
                'category': 'nature',
                'latitude': 9.4981,
                'longitude': 76.3388,
                'image_present': 'https://images.unsplash.com/photo-1548013146-72479768bada?auto=format&fit=crop&w=1200&q=80',
                'image_past': 'https://images.unsplash.com/photo-1564507004663-b84c66e70aa1?auto=format&fit=crop&w=1200&q=80',
            },
            {
                'name': 'Munnar',
                'description': 'A town in the Western Ghats mountain range in India’s Kerala state. A hill station and former resort for the British Raj elite, it\'s surrounded by rolling hills dotted with tea plantations.',
                'country': 'India',
                'city': 'Munnar',
                'category': 'mountain',
                'latitude': 10.0889,
                'longitude': 77.0595,
                'image_present': 'https://images.unsplash.com/photo-1500534314209-a25ddb2bd429?auto=format&fit=crop&w=1200&q=80',
                'image_past': 'https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?auto=format&fit=crop&w=1200&q=80',
            },
            {
                'name': 'Taj Mahal',
                'description': 'An immense mausoleum of white marble, built in Agra between 1631 and 1648 by order of the Mughal emperor Shah Jahan in memory of his favourite wife.',
                'country': 'India',
                'city': 'Agra',
                'category': 'historical',
                'latitude': 27.1751,
                'longitude': 78.0421,
                'image_present': 'https://images.unsplash.com/photo-1548013146-72479768bada?auto=format&fit=crop&w=1200&q=80',
                'image_past': 'https://images.unsplash.com/photo-1533107862482-0e6974b06ec4?auto=format&fit=crop&w=1200&q=80',
            },
            {
                'name': 'Jaipur',
                'description': 'The capital of India’s Rajasthan state. It evokes the royal family that once ruled the region and that, in 1727, founded what is now called the Old City, or “Pink City” for its trademark building color.',
                'country': 'India',
                'city': 'Jaipur',
                'category': 'historical',
                'latitude': 26.9124,
                'longitude': 75.7873,
                'image_present': 'https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?auto=format&fit=crop&w=1200&q=80',
                'image_past': 'https://images.unsplash.com/photo-1469474968028-56623f02e42e?auto=format&fit=crop&w=1200&q=80',
            },
            {
                'name': 'Goa',
                'description': 'A state in western India with coastlines stretching along the Arabian Sea. Its long history as a Portuguese colony prior to 1961 is evident in its preserved 17th-century churches and the area’s tropical spice plantations.',
                'country': 'India',
                'city': 'Goa',
                'category': 'beach',
                'latitude': 15.2993,
                'longitude': 74.1240,
                'image_present': 'https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?auto=format&fit=crop&w=1200&q=80',
                'image_past': 'https://images.unsplash.com/photo-1512453979798-5ea266f8880c?auto=format&fit=crop&w=1200&q=80',
            },
            # International
            {
                'name': 'Eiffel Tower',
                'description': 'The iconic iron lattice tower in Paris, France. A must-visit landmark offering breathtaking views of the city.',
                'country': 'France',
                'city': 'Paris',
                'category': 'historical',
                'latitude': 48.8584,
                'longitude': 2.2945,
                'image_present': 'https://images.unsplash.com/photo-1529429617124-aee7ef6bb0d7?auto=format&fit=crop&w=1200&q=80',
                'image_past': 'https://images.unsplash.com/photo-1529333166437-7750a6dd5a70?auto=format&fit=crop&w=1200&q=80',
            },
            {
                'name': 'Santorini',
                'description': 'A stunning Greek island known for its white-washed buildings, blue-domed churches, and spectacular sunsets.',
                'country': 'Greece',
                'city': 'Santorini',
                'category': 'beach',
                'latitude': 36.3932,
                'longitude': 25.4615,
                'image_present': 'https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?auto=format&fit=crop&w=1200&q=80',
                'image_past': 'https://images.unsplash.com/photo-1500534314209-a25ddb2bd429?auto=format&fit=crop&w=1200&q=80',
            },
            {
                'name': 'Machu Picchu',
                'description': 'Ancient Incan citadel set high in the Andes Mountains in Peru. One of the New Seven Wonders of the World.',
                'country': 'Peru',
                'city': 'Cusco',
                'category': 'historical',
                'latitude': -13.1631,
                'longitude': -72.5450,
                'image_present': 'https://images.unsplash.com/photo-1505672678657-cc7037095e2c?auto=format&fit=crop&w=1200&q=80',
                'image_past': 'https://images.unsplash.com/photo-1469474968028-56623f02e42e?auto=format&fit=crop&w=1200&q=80',
            },
            {
                'name': 'Mount Fuji',
                'description': 'Japan\'s highest and most iconic mountain. A sacred symbol offering incredible hiking and views.',
                'country': 'Japan',
                'city': 'Tokyo',
                'category': 'mountain',
                'latitude': 35.3606,
                'longitude': 138.7278,
                'image_present': 'https://images.unsplash.com/photo-1472214103451-9374bd1c798e?auto=format&fit=crop&w=1200&q=80',
                'image_past': 'https://images.unsplash.com/photo-1478700808228-645e2b105838?auto=format&fit=crop&w=1200&q=80',
            },
            {
                'name': 'Grand Canyon',
                'description': 'Massive natural wonder carved by the Colorado River. Known for its colorful layered rocks and vast landscapes.',
                'country': 'USA',
                'city': 'Arizona',
                'category': 'nature',
                'latitude': 36.1069,
                'longitude': -112.1129,
                'image_present': 'https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?auto=format&fit=crop&w=1200&q=80',
                'image_past': 'https://images.unsplash.com/photo-1523419409543-0c1df022bdd1?auto=format&fit=crop&w=1200&q=80',
            },
            # New International Destinations
            {
                'name': 'Colosseum',
                'description': 'An ancient Roman amphitheater in the center of Rome, Italy. A masterpiece of architecture and engineering.',
                'country': 'Italy',
                'city': 'Rome',
                'category': 'historical',
                'latitude': 41.8902,
                'longitude': 12.4922,
                'image_present': 'https://images.unsplash.com/photo-1552832230-c0197dd311b5?auto=format&fit=crop&w=1200&q=80',
                'image_past': 'https://images.unsplash.com/photo-1569982273913-e051333a4994?auto=format&fit=crop&w=1200&q=80',
            },
            {
                'name': 'Sydney Opera House',
                'description': 'A multi-venue performing arts centre at Sydney Harbour in Sydney, New South Wales, Australia.',
                'country': 'Australia',
                'city': 'Sydney',
                'category': 'entertainment',
                'latitude': -33.8568,
                'longitude': 151.2153,
                'image_present': 'https://images.unsplash.com/photo-1524293581273-79a027986520?auto=format&fit=crop&w=1200&q=80',
                'image_past': 'https://images.unsplash.com/photo-1549180085-4d69b2c7a0a3?auto=format&fit=crop&w=1200&q=80',
            },
            {
                'name': 'Pyramids of Giza',
                'description': 'The Great Pyramid of Giza, the Pyramid of Khafre, and the Pyramid of Menkaure, along with their associated pyramid complexes and the Great Sphinx of Giza.',
                'country': 'Egypt',
                'city': 'Giza',
                'category': 'historical',
                'latitude': 29.9792,
                'longitude': 31.1342,
                'image_present': 'https://images.unsplash.com/photo-1572252192439-908a1555a3a3?auto=format&fit=crop&w=1200&q=80',
                'image_past': 'https://images.unsplash.com/photo-1572252192439-908a1555a3a3?auto=format&fit=crop&w=1200&q=80',
            },
            {
                'name': 'Bora Bora',
                'description': 'A small South Pacific island northwest of Tahiti in French Polynesia. Surrounded by sand-fringed motus (islets) and a turquoise lagoon protected by a coral reef, it’s known for its scuba diving.',
                'country': 'French Polynesia',
                'city': 'Bora Bora',
                'category': 'beach',
                'latitude': -16.5004,
                'longitude': -151.7415,
                'image_present': 'https://images.unsplash.com/photo-1506748686214-e9df14d4d9d0?auto=format&fit=crop&w=1200&q=80',
                'image_past': 'https://images.unsplash.com/photo-1506748686214-e9df14d4d9d0?auto=format&fit=crop&w=1200&q=80',
            },
            {
                'name': 'Serengeti National Park',
                'description': 'A large national park in northern Tanzania that stretches over 14,763 km². It is most famous for its annual migration of over 1.5 million white-bearded (or brindled) wildebeest and 250,000 zebra.',
                'country': 'Tanzania',
                'city': 'Serengeti',
                'category': 'nature',
                'latitude': -2.3333,
                'longitude': 34.8333,
                'image_present': 'https://images.unsplash.com/photo-1512453979798-5ea266f8880c?auto=format&fit=crop&w=1200&q=80',
                'image_past': 'https://images.unsplash.com/photo-1512453979798-5ea266f8880c?auto=format&fit=crop&w=1200&q=80',
            },
        ]

        # Optionally extend with large dataset from JSON file
        data_dir = os.path.join(os.path.dirname(__file__), 'data')
        data_path = os.path.join(data_dir, 'destinations_100.json')
        if os.path.exists(data_path):
            try:
                with open(data_path, 'r', encoding='utf-8') as f:
                    external = json.load(f)
                    if isinstance(external, list):
                        self.stdout.write(f"Loaded {len(external)} destinations from JSON dataset.")
                        destinations_data.extend(external)
                    else:
                        self.stdout.write(self.style.WARNING('destinations_100.json is not a list; skipping.'))
            except Exception as e:
                self.stdout.write(self.style.WARNING(f'Failed to load destinations_100.json: {e}'))

        destinations = []
        for dest_data in destinations_data:
            # normalize and backfill optional fields
            defaults = {key: value for key, value in dest_data.items() if key != 'name'}
            name = dest_data.get('name')
            city = dest_data.get('city', '')
            # backfill images if missing using Unsplash source (royalty-free)
            if not defaults.get('image_present'):
                q = f"{name} {city}".strip().replace(' ', ',')
                defaults['image_present'] = f"https://source.unsplash.com/1200x800/?{q}"
            if not defaults.get('image_past'):
                q = f"{name} {city} historical".strip().replace(' ', ',')
                defaults['image_past'] = f"https://source.unsplash.com/1200x800/?{q}"
            if users:
                defaults.setdefault('created_by', users[0])
            dest, created = Destination.objects.update_or_create(
                name=name,
                defaults=defaults
            )
            destinations.append(dest)
            action = 'Created' if created else 'Updated'
            self.stdout.write(f'{action} destination: {dest.name}')

        if not destinations:
            destinations = list(Destination.objects.all()[:5])

        # Sample reviews
        review_texts = [
            {
                'title': 'Absolutely Amazing!',
                'review_text': 'One of the best places I have ever visited. The experience was unforgettable and I highly recommend it to everyone!',
                'rating': 5
            },
            {
                'title': 'Great Experience',
                'review_text': 'Had a wonderful time exploring this place. The views were stunning and the local culture was fascinating.',
                'rating': 4
            },
            {
                'title': 'Worth the Visit',
                'review_text': 'A beautiful destination with lots to see and do. Would definitely come back again!',
                'rating': 5
            },
        ]

        for i, dest in enumerate(destinations[:3]):
            if users and not Review.objects.filter(destination=dest, user=users[0]).exists():
                Review.objects.create(
                    destination=dest,
                    user=users[0],
                    **review_texts[i]
                )
                dest.update_rating()
                self.stdout.write(f'Created review for: {dest.name}')

        # Sample blog posts
        post_contents = [
            {
                'title': 'My Incredible Journey',
                'content': '''I recently visited this amazing destination and it completely exceeded my expectations. 
                
The journey started early in the morning as we made our way through beautiful landscapes. The weather was perfect, and the locals were incredibly welcoming.

What struck me most was the rich cultural heritage and the stunning natural beauty. Every corner had something new to discover, from hidden cafes to breathtaking viewpoints.

I spent several days exploring and each day brought new adventures. The food was delicious, the people were friendly, and the memories will last a lifetime.

If you're planning a trip here, I highly recommend taking your time to truly experience everything this place has to offer. Don't rush through it – savor every moment!''',
                'rating': 5
            },
            {
                'title': 'A Week of Adventure',
                'content': '''Just returned from an amazing week of exploring this incredible destination. Here are my highlights:

Day 1-2: Arrived and spent time getting oriented. The architecture is absolutely stunning and walking through the streets feels like stepping back in time.

Day 3-4: Ventured out to nearby attractions. The natural scenery is breathtaking – perfect for photography enthusiasts!

Day 5-6: Immersed myself in local culture, trying traditional food and meeting wonderful people. The cuisine here is a highlight in itself.

Day 7: Final day spent revisiting favorite spots and shopping for souvenirs.

Tips for travelers: Book accommodations in advance, try the local transportation, and don't be afraid to venture off the beaten path!''',
                'rating': 4
            },
        ]

        for i, dest in enumerate(destinations[:2]):
            if users and not Post.objects.filter(destination=dest, author=users[0]).exists():
                Post.objects.create(
                    destination=dest,
                    author=users[0],
                    **post_contents[i]
                )
                self.stdout.write(f'Created post for: {dest.name}')

        self.stdout.write(self.style.SUCCESS('Successfully populated database with sample data!'))
        self.stdout.write('\nYou can now:')
        self.stdout.write('- Visit destinations in the frontend')
        self.stdout.write('- Login with: user1@example.com / password123')
        self.stdout.write('- Explore posts and reviews')
