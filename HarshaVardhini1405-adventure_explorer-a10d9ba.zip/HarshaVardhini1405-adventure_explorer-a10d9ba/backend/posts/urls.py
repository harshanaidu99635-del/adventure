from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import PostViewSet, CommentViewSet, PostImageViewSet

router = DefaultRouter()
router.register(r'', PostViewSet, basename='post')
router.register(r'comments', CommentViewSet, basename='comment')
router.register(r'images', PostImageViewSet, basename='post-image')

urlpatterns = [
    path('', include(router.urls)),
]
