from django.db import models
from django.contrib.auth import get_user_model
from destinations.models import Destination

User = get_user_model()


class Post(models.Model):
    """Blog post model for travel stories."""
    
    title = models.CharField(max_length=200)
    content = models.TextField()
    destination = models.ForeignKey(Destination, on_delete=models.CASCADE, related_name='posts')
    author = models.ForeignKey(User, on_delete=models.CASCADE, related_name='posts')
    
    # Rating for this specific post/experience
    rating = models.IntegerField(choices=[(i, i) for i in range(1, 6)], default=5)
    
    # Images
    featured_image = models.ImageField(upload_to='posts/', blank=True, null=True)
    
    # Engagement
    likes_count = models.IntegerField(default=0)
    comments_count = models.IntegerField(default=0)
    views = models.IntegerField(default=0)
    
    # Status
    is_published = models.BooleanField(default=True)
    
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        ordering = ['-created_at']
        indexes = [
            models.Index(fields=['-created_at']),
            models.Index(fields=['destination', '-created_at']),
            models.Index(fields=['author', '-created_at']),
        ]
    
    def __str__(self):
        return f"{self.title} by {self.author.username}"
    
    def update_likes_count(self):
        """Update likes count."""
        self.likes_count = self.likes.count()
        self.save(update_fields=['likes_count'])
    
    def update_comments_count(self):
        """Update comments count."""
        self.comments_count = self.comments.count()
        self.save(update_fields=['comments_count'])


class PostImage(models.Model):
    """Additional images for blog posts."""
    
    post = models.ForeignKey(Post, on_delete=models.CASCADE, related_name='images')
    image = models.ImageField(upload_to='posts/gallery/')
    caption = models.CharField(max_length=200, blank=True)
    order = models.IntegerField(default=0)
    uploaded_at = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        ordering = ['order', '-uploaded_at']
    
    def __str__(self):
        return f"Image for {self.post.title}"


class Like(models.Model):
    """Like model for posts."""
    
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='likes')
    post = models.ForeignKey(Post, on_delete=models.CASCADE, related_name='likes')
    created_at = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        unique_together = ['user', 'post']
        ordering = ['-created_at']
    
    def __str__(self):
        return f"{self.user.username} likes {self.post.title}"


class Comment(models.Model):
    """Comment model for posts."""
    
    post = models.ForeignKey(Post, on_delete=models.CASCADE, related_name='comments')
    author = models.ForeignKey(User, on_delete=models.CASCADE, related_name='comments')
    content = models.TextField()
    parent = models.ForeignKey('self', on_delete=models.CASCADE, null=True, blank=True, related_name='replies')
    
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        ordering = ['-created_at']
    
    def __str__(self):
        return f"Comment by {self.author.username} on {self.post.title}"
