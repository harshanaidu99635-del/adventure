from rest_framework import serializers
from .models import Post, PostImage, Like, Comment
from destinations.serializers import DestinationListSerializer


class PostImageSerializer(serializers.ModelSerializer):
    class Meta:
        model = PostImage
        fields = ['id', 'image', 'caption', 'order']


class CommentSerializer(serializers.ModelSerializer):
    author_username = serializers.CharField(source='author.username', read_only=True)
    author_profile_pic = serializers.ImageField(source='author.profile.profile_picture', read_only=True)
    replies = serializers.SerializerMethodField()
    
    class Meta:
        model = Comment
        fields = ['id', 'content', 'author', 'author_username', 'author_profile_pic',
                  'parent', 'replies', 'created_at', 'updated_at']
        read_only_fields = ['author', 'created_at', 'updated_at']
    
    def get_replies(self, obj):
        if obj.parent is None:  # Only get replies for top-level comments
            replies = obj.replies.all()
            return CommentSerializer(replies, many=True).data
        return []


class PostListSerializer(serializers.ModelSerializer):
    """Serializer for listing posts (summary view)."""
    author_username = serializers.CharField(source='author.username', read_only=True)
    author_profile_pic = serializers.ImageField(source='author.profile.profile_picture', read_only=True)
    destination_name = serializers.CharField(source='destination.name', read_only=True)
    is_liked = serializers.SerializerMethodField()
    
    class Meta:
        model = Post
        fields = ['id', 'title', 'content', 'destination', 'destination_name',
                  'author', 'author_username', 'author_profile_pic', 'rating',
                  'featured_image', 'likes_count', 'comments_count', 'views',
                  'is_liked', 'created_at']
    
    def get_is_liked(self, obj):
        request = self.context.get('request')
        if request and request.user.is_authenticated:
            return Like.objects.filter(user=request.user, post=obj).exists()
        return False


class PostDetailSerializer(serializers.ModelSerializer):
    """Serializer for post details (full view)."""
    author_username = serializers.CharField(source='author.username', read_only=True)
    author_profile_pic = serializers.ImageField(source='author.profile.profile_picture', read_only=True)
    destination = DestinationListSerializer(read_only=True)
    images = PostImageSerializer(many=True, read_only=True)
    comments = CommentSerializer(many=True, read_only=True)
    is_liked = serializers.SerializerMethodField()
    
    class Meta:
        model = Post
        fields = ['id', 'title', 'content', 'destination', 'author', 
                  'author_username', 'author_profile_pic', 'rating', 
                  'featured_image', 'images', 'likes_count', 'comments_count', 
                  'views', 'is_liked', 'comments', 'created_at', 'updated_at']
    
    def get_is_liked(self, obj):
        request = self.context.get('request')
        if request and request.user.is_authenticated:
            return Like.objects.filter(user=request.user, post=obj).exists()
        return False


class PostCreateUpdateSerializer(serializers.ModelSerializer):
    """Serializer for creating/updating posts."""
    
    class Meta:
        model = Post
        fields = ['title', 'content', 'destination', 'rating', 'featured_image']
    
    def validate_rating(self, value):
        if value < 1 or value > 5:
            raise serializers.ValidationError("Rating must be between 1 and 5.")
        return value


class CommentCreateSerializer(serializers.ModelSerializer):
    """Serializer for creating comments."""
    
    class Meta:
        model = Comment
        fields = ['content', 'parent']
