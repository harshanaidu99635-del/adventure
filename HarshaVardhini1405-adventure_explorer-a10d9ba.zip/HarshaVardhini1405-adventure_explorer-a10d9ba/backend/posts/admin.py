from django.contrib import admin
from .models import Post, PostImage, Like, Comment


class PostImageInline(admin.TabularInline):
    model = PostImage
    extra = 1


@admin.register(Post)
class PostAdmin(admin.ModelAdmin):
    list_display = ['title', 'author', 'destination', 'rating', 'likes_count', 
                    'comments_count', 'is_published', 'created_at']
    list_filter = ['is_published', 'rating', 'created_at']
    search_fields = ['title', 'content', 'author__username', 'destination__name']
    readonly_fields = ['likes_count', 'comments_count', 'views', 'created_at', 'updated_at']
    inlines = [PostImageInline]
    
    fieldsets = (
        ('Content', {
            'fields': ('title', 'content', 'destination', 'author', 'rating', 'featured_image')
        }),
        ('Statistics', {
            'fields': ('likes_count', 'comments_count', 'views')
        }),
        ('Status', {
            'fields': ('is_published', 'created_at', 'updated_at')
        }),
    )


@admin.register(Comment)
class CommentAdmin(admin.ModelAdmin):
    list_display = ['author', 'post', 'content_preview', 'created_at']
    list_filter = ['created_at']
    search_fields = ['author__username', 'post__title', 'content']
    
    def content_preview(self, obj):
        return obj.content[:50] + '...' if len(obj.content) > 50 else obj.content
    content_preview.short_description = 'Content'


@admin.register(Like)
class LikeAdmin(admin.ModelAdmin):
    list_display = ['user', 'post', 'created_at']
    list_filter = ['created_at']
    search_fields = ['user__username', 'post__title']
