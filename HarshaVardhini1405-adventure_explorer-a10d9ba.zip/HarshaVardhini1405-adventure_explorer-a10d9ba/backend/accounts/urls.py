from django.urls import path
from .views import (
    RegisterView,
    UserDetailView,
    UserProfileView,
    current_user,
    update_profile
)

urlpatterns = [
    path('register/', RegisterView.as_view(), name='register'),
    path('me/', UserDetailView.as_view(), name='user-detail'),
    path('current/', current_user, name='current-user'),
    path('profile/update/', update_profile, name='update-profile'),
    path('<str:username>/', UserProfileView.as_view(), name='user-profile'),
]
