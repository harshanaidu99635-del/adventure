from django.contrib import admin
from .models import Review, ReviewHelpful


@admin.register(Review)
class ReviewAdmin(admin.ModelAdmin):
    list_display = ['destination', 'user', 'rating', 'title', 'helpful_count', 
                    'is_approved', 'is_reported', 'created_at']
    list_filter = ['rating', 'is_approved', 'is_reported', 'created_at']
    search_fields = ['title', 'review_text', 'user__username', 'destination__name']
    readonly_fields = ['helpful_count', 'created_at', 'updated_at']
    
    fieldsets = (
        ('Review Details', {
            'fields': ('destination', 'user', 'rating', 'title', 'review_text', 'visit_date')
        }),
        ('Engagement', {
            'fields': ('helpful_count',)
        }),
        ('Moderation', {
            'fields': ('is_approved', 'is_reported')
        }),
        ('Timestamps', {
            'fields': ('created_at', 'updated_at')
        }),
    )
    
    actions = ['approve_reviews', 'mark_as_reported']
    
    def approve_reviews(self, request, queryset):
        queryset.update(is_approved=True, is_reported=False)
        self.message_user(request, f"{queryset.count()} reviews approved.")
    approve_reviews.short_description = "Approve selected reviews"
    
    def mark_as_reported(self, request, queryset):
        queryset.update(is_reported=True)
        self.message_user(request, f"{queryset.count()} reviews marked as reported.")
    mark_as_reported.short_description = "Mark as reported"


@admin.register(ReviewHelpful)
class ReviewHelpfulAdmin(admin.ModelAdmin):
    list_display = ['review', 'user', 'created_at']
    list_filter = ['created_at']
    search_fields = ['review__title', 'user__username']
