from django.db.models.signals import post_save, post_delete
from django.dispatch import receiver
from .models import Review, ReviewHelpful


@receiver(post_save, sender=Review)
def update_destination_rating_on_save(sender, instance, created, **kwargs):
    """Update destination rating when a review is saved."""
    instance.destination.update_rating()


@receiver(post_delete, sender=Review)
def update_destination_rating_on_delete(sender, instance, **kwargs):
    """Update destination rating when a review is deleted."""
    instance.destination.update_rating()


@receiver(post_save, sender=ReviewHelpful)
def update_helpful_count_on_save(sender, instance, created, **kwargs):
    """Update helpful count when a vote is added."""
    if created:
        review = instance.review
        review.helpful_count = review.helpful_votes.count()
        review.save(update_fields=['helpful_count'])


@receiver(post_delete, sender=ReviewHelpful)
def update_helpful_count_on_delete(sender, instance, **kwargs):
    """Update helpful count when a vote is removed."""
    review = instance.review
    review.helpful_count = review.helpful_votes.count()
    review.save(update_fields=['helpful_count'])
