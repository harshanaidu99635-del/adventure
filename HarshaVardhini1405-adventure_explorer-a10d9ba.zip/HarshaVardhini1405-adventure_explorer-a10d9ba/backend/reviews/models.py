from django.db import models
from django.contrib.auth import get_user_model
from django.core.validators import MinValueValidator, MaxValueValidator
from destinations.models import Destination

User = get_user_model()


class Review(models.Model):
    """Review model for destinations."""
    
    destination = models.ForeignKey(Destination, on_delete=models.CASCADE, related_name='reviews')
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='reviews')
    
    # Rating and review
    rating = models.IntegerField(
        validators=[MinValueValidator(1), MaxValueValidator(5)],
        help_text="Rating from 1 to 5"
    )
    title = models.CharField(max_length=200)
    review_text = models.TextField()
    
    # Additional details
    visit_date = models.DateField(null=True, blank=True)
    
    # Helpful votes
    helpful_count = models.IntegerField(default=0)
    
    # Moderation
    is_approved = models.BooleanField(default=True)
    is_reported = models.BooleanField(default=False)
    
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        unique_together = ['destination', 'user']  # One review per user per destination
        ordering = ['-created_at']
        indexes = [
            models.Index(fields=['destination', '-created_at']),
            models.Index(fields=['user', '-created_at']),
        ]
    
    def __str__(self):
        return f"Review by {self.user.username} for {self.destination.name}"


class ReviewHelpful(models.Model):
    """Track helpful votes on reviews."""
    
    review = models.ForeignKey(Review, on_delete=models.CASCADE, related_name='helpful_votes')
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    created_at = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        unique_together = ['review', 'user']
        ordering = ['-created_at']
    
    def __str__(self):
        return f"{self.user.username} found review helpful"
