from rest_framework import viewsets, status, filters, generics
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticatedOrReadOnly, IsAuthenticated
from django_filters.rest_framework import DjangoFilterBackend
from django.db.models import Avg, Count, Q
from .models import Review, ReviewHelpful
from .serializers import (
    ReviewSerializer,
    ReviewCreateUpdateSerializer,
    ReviewStatsSerializer
)


class ReviewViewSet(viewsets.ModelViewSet):
    """ViewSet for Review CRUD operations."""
    
    queryset = Review.objects.filter(is_approved=True).select_related('user', 'destination')
    permission_classes = [IsAuthenticatedOrReadOnly]
    filter_backends = [DjangoFilterBackend, filters.SearchFilter, filters.OrderingFilter]
    filterset_fields = ['destination', 'user', 'rating']
    search_fields = ['title', 'review_text']
    ordering_fields = ['created_at', 'rating', 'helpful_count']
    ordering = ['-created_at']
    
    def get_serializer_class(self):
        if self.action in ['create', 'update', 'partial_update']:
            return ReviewCreateUpdateSerializer
        return ReviewSerializer
    
    def perform_create(self, serializer):
        serializer.save(user=self.request.user)
    
    @action(detail=True, methods=['post'], permission_classes=[IsAuthenticated])
    def helpful(self, request, pk=None):
        """Mark a review as helpful."""
        review = self.get_object()
        helpful, created = ReviewHelpful.objects.get_or_create(
            user=request.user,
            review=review
        )
        
        if created:
            return Response({'status': 'marked as helpful'}, status=status.HTTP_201_CREATED)
        return Response({'status': 'already marked'}, status=status.HTTP_200_OK)
    
    @action(detail=True, methods=['post'], permission_classes=[IsAuthenticated])
    def unhelpful(self, request, pk=None):
        """Remove helpful mark from a review."""
        review = self.get_object()
        deleted = ReviewHelpful.objects.filter(
            user=request.user,
            review=review
        ).delete()
        
        if deleted[0] > 0:
            return Response({'status': 'unhelpful mark removed'}, status=status.HTTP_200_OK)
        return Response({'status': 'not marked as helpful'}, status=status.HTTP_404_NOT_FOUND)
    
    @action(detail=True, methods=['post'], permission_classes=[IsAuthenticated])
    def report(self, request, pk=None):
        """Report a review."""
        review = self.get_object()
        review.is_reported = True
        review.save(update_fields=['is_reported'])
        return Response({'status': 'review reported'}, status=status.HTTP_200_OK)
    
    @action(detail=False, methods=['get'])
    def destination_stats(self, request):
        """Get review statistics for a destination."""
        destination_id = request.query_params.get('destination')
        
        if not destination_id:
            return Response(
                {'error': 'destination parameter is required'},
                status=status.HTTP_400_BAD_REQUEST
            )
        
        reviews = self.queryset.filter(destination_id=destination_id)
        
        # Calculate statistics
        avg_rating = reviews.aggregate(Avg('rating'))['rating__avg'] or 0
        total_reviews = reviews.count()
        
        # Rating distribution
        rating_dist = {}
        for i in range(1, 6):
            rating_dist[str(i)] = reviews.filter(rating=i).count()
        
        stats = {
            'average_rating': round(avg_rating, 2),
            'total_reviews': total_reviews,
            'rating_distribution': rating_dist
        }
        
        serializer = ReviewStatsSerializer(stats)
        return Response(serializer.data)
    
    @action(detail=False, methods=['get'], permission_classes=[IsAuthenticated])
    def my_reviews(self, request):
        """Get current user's reviews."""
        reviews = self.queryset.filter(user=request.user)
        page = self.paginate_queryset(reviews)
        if page is not None:
            serializer = ReviewSerializer(page, many=True, context={'request': request})
            return self.get_paginated_response(serializer.data)
        serializer = ReviewSerializer(reviews, many=True, context={'request': request})
        return Response(serializer.data)
