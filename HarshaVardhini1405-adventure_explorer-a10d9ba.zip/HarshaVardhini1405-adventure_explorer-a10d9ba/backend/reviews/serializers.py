from rest_framework import serializers
from .models import Review, ReviewHelpful
from destinations.serializers import DestinationListSerializer


class ReviewSerializer(serializers.ModelSerializer):
    user_username = serializers.CharField(source='user.username', read_only=True)
    user_profile_pic = serializers.ImageField(source='user.profile.profile_picture', read_only=True)
    destination_name = serializers.CharField(source='destination.name', read_only=True)
    is_helpful = serializers.SerializerMethodField()
    
    class Meta:
        model = Review
        fields = ['id', 'destination', 'destination_name', 'user', 'user_username', 
                  'user_profile_pic', 'rating', 'title', 'review_text', 'visit_date',
                  'helpful_count', 'is_helpful', 'created_at', 'updated_at']
        read_only_fields = ['user', 'helpful_count', 'created_at', 'updated_at']
    
    def get_is_helpful(self, obj):
        request = self.context.get('request')
        if request and request.user.is_authenticated:
            return ReviewHelpful.objects.filter(user=request.user, review=obj).exists()
        return False
    
    def validate_rating(self, value):
        if value < 1 or value > 5:
            raise serializers.ValidationError("Rating must be between 1 and 5.")
        return value


class ReviewCreateUpdateSerializer(serializers.ModelSerializer):
    """Serializer for creating/updating reviews."""
    
    class Meta:
        model = Review
        fields = ['destination', 'rating', 'title', 'review_text', 'visit_date']
    
    def validate_rating(self, value):
        if value < 1 or value > 5:
            raise serializers.ValidationError("Rating must be between 1 and 5.")
        return value


class ReviewStatsSerializer(serializers.Serializer):
    """Serializer for review statistics."""
    average_rating = serializers.DecimalField(max_digits=3, decimal_places=2)
    total_reviews = serializers.IntegerField()
    rating_distribution = serializers.DictField()
